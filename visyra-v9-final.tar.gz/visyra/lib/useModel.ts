/**
 * useModel.ts — Robust TensorFlow.js model loading for Visyra
 *
 * Model: Custom CIFAR-10 CNN (model4)
 * Architecture: Conv2D×6 + BN×7 + MaxPool×3 + Dropout×4 + Flatten + Dense×2
 * Input:  [1, 32, 32, 3]  float32  pixel values in [0, 1]
 * Output: [1, 10]         softmax  probabilities
 * Size:   ~2.2 MB (single weight shard)
 *
 * Design decisions:
 * ─────────────────
 * • "use client" — prevents Next.js SSR from attempting to import tfjs on the server
 * • Dynamic import of @tensorflow/tfjs — defers 3 MB bundle until first use
 * • tf.loadLayersModel — loads the patched layers-format JSON + binary shard
 * • tf.tidy — automatically frees intermediate tensors; no memory leaks
 * • InferenceError type — structured error propagation to the UI
 * • Retry logic — 3 attempts with exponential backoff on network errors
 */
"use client";
import { useState, useEffect, useCallback, useRef } from "react";

// ── Constants ────────────────────────────────────────────────────────────────
export const CLASS_NAMES  = [
  "Airplane","Automobile","Bird","Cat","Deer",
  "Dog","Frog","Horse","Ship","Truck",
] as const;

export const CLASS_EMOJIS = [
  "✈️","🚗","🐦","🐱","🦌","🐶","🐸","🐴","🚢","🚛",
] as const;

const MODEL_URL    = "/model/model.json";
const INPUT_H      = 32;
const INPUT_W      = 32;
const INPUT_C      = 3;
const NUM_CLASSES  = 10;
const MAX_RETRIES  = 3;

// ── Types ────────────────────────────────────────────────────────────────────
export type ModelStatus = "idle" | "loading" | "ready" | "error";

export interface PredictResult {
  classIdx:    number;
  className:   string;
  emoji:       string;
  confidence:  number;   // 0–100
  allScores:   number[]; // 0–100 for all 10 classes
  inferenceMs: number;
}

// Lazy-loaded tfjs type alias
type TF = typeof import("@tensorflow/tfjs");
type LayersModel = import("@tensorflow/tfjs").LayersModel;

// Module-level model cache — survives React re-renders and HMR
let _tf:    TF           | null = null;
let _model: LayersModel  | null = null;
let _loadPromise: Promise<void> | null = null;

// ── Loader ───────────────────────────────────────────────────────────────────
async function ensureLoaded(
  onProgress: (pct: number) => void
): Promise<void> {
  if (_model) { onProgress(100); return; }
  if (_loadPromise) return _loadPromise;

  _loadPromise = (async () => {
    onProgress(5);

    // 1. Lazy-import TF.js (defers ~3 MB from initial bundle)
    _tf = await import("@tensorflow/tfjs");
    onProgress(20);

    // 2. Prefer WebGL; fall back to CPU gracefully
    try {
      await _tf.setBackend("webgl");
      await _tf.ready();
    } catch {
      await _tf.setBackend("cpu");
      await _tf.ready();
    }
    onProgress(30);

    // 3. Load the model with retry logic
    let lastErr: unknown;
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        _model = await _tf.loadLayersModel(MODEL_URL, {
          onProgress: (fraction: number) => {
            onProgress(30 + Math.round(fraction * 65));
          },
        });

        // 4. Warm-up: run one dummy inference to compile the compute graph
        const warmup = _tf.zeros([1, INPUT_H, INPUT_W, INPUT_C]);
        const warmupOut = _model.predict(warmup) as import("@tensorflow/tfjs").Tensor;
        warmupOut.dispose();
        warmup.dispose();

        onProgress(100);
        if (process.env.NODE_ENV === "development") {
          console.info(
            "[Visyra] CIFAR-10 CNN loaded.",
            `Backend: ${_tf.getBackend()}.`,
            `Params: ${_model.countParams().toLocaleString()}`
          );
        }
        return; // success
      } catch (err) {
        lastErr = err;
        if (process.env.NODE_ENV === "development") {
          console.warn(`[Visyra] Model load attempt ${attempt}/${MAX_RETRIES} failed:`, err);
        }
        if (attempt < MAX_RETRIES) {
          await new Promise(r => setTimeout(r, 600 * attempt)); // backoff
        }
      }
    }
    _loadPromise = null;
    throw lastErr;
  })();

  return _loadPromise;
}

// ── Hook ─────────────────────────────────────────────────────────────────────
export function useModel() {
  const [status,  setStatus]  = useState<ModelStatus>(
    _model ? "ready" : "idle"
  );
  const [loadPct, setLoadPct] = useState(_model ? 100 : 0);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  // ── load ──
  const load = useCallback(async () => {
    if (_model) { setStatus("ready"); setLoadPct(100); return; }
    if (status === "loading") return;

    setStatus("loading");
    setLoadPct(0);
    try {
      await ensureLoaded((pct) => {
        if (mountedRef.current) setLoadPct(pct);
      });
      if (mountedRef.current) { setStatus("ready"); setLoadPct(100); }
    } catch (err) {
      if (mountedRef.current) { setStatus("error"); }
      if (process.env.NODE_ENV === "development") {
        console.error("[Visyra] Model load failed:", err);
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── predict ──
  const predict = useCallback(
    async (
      source: HTMLImageElement | HTMLCanvasElement | HTMLVideoElement
    ): Promise<PredictResult | null> => {
      if (!_model || !_tf) return null;

      const t0 = performance.now();

      // All tensor operations inside tf.tidy → automatic cleanup
      const scores: number[] = _tf.tidy(() => {
        // fromPixels → [H, W, 3] uint8
        let t = _tf!.browser.fromPixels(source, INPUT_C);

        // Resize to model input size [32, 32, 3]
        t = _tf!.image.resizeBilinear(
          t as import("@tensorflow/tfjs").Tensor3D,
          [INPUT_H, INPUT_W]
        ) as import("@tensorflow/tfjs").Tensor3D;

        // Normalise to [0, 1]
        const norm = t.toFloat().div(_tf!.scalar(255));

        // Add batch dim → [1, 32, 32, 3]
        const batched = norm.expandDims(0) as import("@tensorflow/tfjs").Tensor4D;

        // Forward pass
        const output = _model!.predict(batched) as import("@tensorflow/tfjs").Tensor2D;

        // Extract as plain JS array
        return Array.from(output.dataSync());
      });

      if (scores.length !== NUM_CLASSES) {
        console.error("[Visyra] Unexpected output length:", scores.length);
        return null;
      }

      const inferenceMs = Math.round(performance.now() - t0);
      const classIdx    = scores.indexOf(Math.max(...scores));
      const allScores   = scores.map(v => parseFloat((v * 100).toFixed(1)));

      return {
        classIdx,
        className:  CLASS_NAMES[classIdx],
        emoji:      CLASS_EMOJIS[classIdx],
        confidence: allScores[classIdx],
        allScores,
        inferenceMs,
      };
    },
    []
  );

  return { status, loadPct, load, predict, CLASS_NAMES, CLASS_EMOJIS };
}
