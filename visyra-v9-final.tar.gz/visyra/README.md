# Visyra

**AI-powered CIFAR-10 Image Classification Platform**

A polished, production-quality web application that runs a trained CNN model entirely in the browser using TensorFlow.js. Built as the final project for **ICT 120 — Intelligent Systems**, BSCS 3B.

---

## Overview

Visyra is a frontend-first AI demonstration platform. Users can upload any image (or pick from curated samples) and receive a real-time CIFAR-10 classification result — predicted class, confidence score, and a full 10-class probability breakdown — all computed locally in the browser with no server round-trip required.

The application doubles as a model evaluation showcase, displaying training metrics, a confusion matrix, per-class validation results, and the CIFAR-10 dataset gallery.

---

## The Model

The trained model (`cifar10_model.keras`) is a **custom Convolutional Neural Network** trained from scratch on the CIFAR-10 dataset.

### Architecture

```
Input: [32, 32, 3]  float32 (normalised to [0, 1])
│
├── Conv2D(32, 3×3, same) → BatchNorm → ReLU
├── Conv2D(32, 3×3, same) → BatchNorm → ReLU → MaxPool(2×2) → Dropout(0.25)
│
├── Conv2D(64, 3×3, same) → BatchNorm → ReLU
├── Conv2D(64, 3×3, same) → BatchNorm → ReLU → MaxPool(2×2) → Dropout(0.25)
│
├── Conv2D(128, 3×3, same) → BatchNorm → ReLU
├── Conv2D(128, 3×3, same) → BatchNorm → ReLU → MaxPool(2×2) → Dropout(0.30)
│
├── Flatten → Dense(128) → BatchNorm → ReLU → Dropout(0.50)
└── Dense(10) → Softmax

Output: [10]  class probabilities
```

### Key stats

| Property | Value |
|---|---|
| Total parameters | 552,874 |
| Trainable parameters | 551,722 |
| Model size (TF.js) | ~2.2 MB |
| Input resolution | 32 × 32 × 3 |
| Output classes | 10 |
| Preprocessing | Normalise pixels to [0, 1] |

### CIFAR-10 Classes

`Airplane · Automobile · Bird · Cat · Deer · Dog · Frog · Horse · Ship · Truck`

---

## Tech Stack

### Frontend

| Technology | Why |
|---|---|
| **Next.js 15** (App Router) | Server components, file-based routing, static export support |
| **TypeScript** | Type safety across the entire codebase |
| **Tailwind CSS** | Utility-first styling with zero-runtime overhead |
| **Framer Motion** | Declarative, interruptible animations for section reveals and microinteractions |
| **Recharts** | Composable React charts for the radar and line charts |
| **Lucide React** | Lightweight, consistent icon set |

### AI / Inference

| Technology | Why |
|---|---|
| **@tensorflow/tfjs** | Runs the model entirely in-browser; no backend required |
| **WebGL backend** | GPU-accelerated tensor operations (falls back to CPU automatically) |
| **Layers model format** | TF.js native format converted from the `.keras` source |

### Training (offline)

| Technology | Why |
|---|---|
| **TensorFlow / Keras 3** | Model definition, training, checkpointing |
| **Python 3.12** | Training scripts and model conversion pipeline |

---

## Project Structure

```
visyra/
├── app/
│   ├── layout.tsx          Root layout — viewport, fonts, metadata
│   ├── page.tsx            Main page — assembles all sections
│   └── globals.css         Design tokens, GPU-composited animations, typography
│
├── components/
│   ├── Background.tsx      Three-layer cursor-reactive aurora + neural particles
│   ├── Cursor.tsx          Custom black dot + trailing ring cursor
│   ├── ParallaxSection.tsx Native rAF-based parallax (no Spring lag)
│   └── sections/
│       ├── Navbar.tsx          Sticky glassmorphism navigation
│       ├── Hero.tsx            Landing hero with staircase + Visyra object
│       ├── UploadPredict.tsx   Drag-and-drop upload + real TF.js inference
│       ├── Metrics.tsx         CNN performance cards + training history chart
│       ├── ConfusionMatrix.tsx Interactive 10×10 heatmap with hover inspection
│       ├── ValidationRuns.tsx  5 validation cards + per-class recall bars
│       └── ClassGallery.tsx    CIFAR-10 class showcase + dataset stats
│
├── lib/
│   └── useModel.ts         TF.js model loading hook — lazy, retry, WebGL/CPU fallback
│
├── constants/
│   └── cifar10.ts          Class definitions (name, emoji, description)
│
├── mock-data/
│   └── index.ts            Evaluation metrics, confusion matrix, validation run data
│
└── public/
    ├── visyra.png          Brand logo / favicon
    └── model/
        ├── model.json          TF.js layers model topology (patched for compatibility)
        └── group1-shard1of1.bin  CNN weight data (~2.2 MB)
```

---

## Model Conversion Pipeline

The `.keras` model format uses Keras 3 serialisation which is incompatible with TF.js out of the box. The conversion pipeline handles three classes of issues:

1. **`batch_shape` → `batch_input_shape`** — TF.js `InputLayer` requires `batch_input_shape`; Keras 3 exports `batch_shape`. Fixed by renaming the key.

2. **`DTypePolicy` objects** — Keras 3 serialises `dtype` as `{"class_name":"DTypePolicy","config":{"name":"float32"}}`. TF.js expects a plain `"float32"` string. Fixed by a recursive replacement pass.

3. **Initialiser format** — Keras 3 adds `module` and `registered_name` fields to initialiser dicts. TF.js only accepts `{"class_name":..., "config":...}`. Fixed by flattening all initialiser objects.

4. **`BatchNormalization` axis** — Keras 3 serialises `axis` as `[-1]` (list); TF.js requires an integer `-1`. Fixed.

5. **`Conv2D` groups** — Keras 3 includes a `groups` field; TF.js @4.x doesn't support it. Removed.

---

## Getting Started

### Prerequisites

- Node.js 18.17 or higher
- npm 9+

### Install

```bash
git clone https://github.com/your-org/visyra.git
cd visyra
npm install
```

### Run development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

The CNN model (~2.2 MB) downloads automatically on first page load and is cached by the browser. Subsequent visits run entirely offline.

### Build for production

```bash
npm run build
npm run start
```

### Type check

```bash
npx tsc --noEmit
```

---

## How Inference Works

1. **Model loads once** — `useModel()` lazily imports `@tensorflow/tfjs`, selects the WebGL backend (falls back to CPU), downloads and compiles the model, then runs a warm-up forward pass to pre-compile the WebGL compute graph.

2. **Image preprocessing** — `tf.browser.fromPixels(imgElement)` decodes the image into a `[H, W, 3]` uint8 tensor, `resizeBilinear([32, 32])` scales it to the model's input size, and `.div(255)` normalises to `[0, 1]`.

3. **Forward pass** — `model.predict(batchedTensor)` runs the CNN and returns a `[1, 10]` float32 tensor of softmax probabilities.

4. **Cleanup** — All intermediate tensors are freed inside `tf.tidy()`. The model is kept in memory for subsequent predictions.

5. **Result display** — `argmax` identifies the predicted class; the full score vector is converted to percentages and visualised as animated bars and a radar chart.

---

## Performance Notes

- **Parallax** uses native `requestAnimationFrame` + `IntersectionObserver`, not Framer Motion spring animations. This eliminates the ~150 ms lag introduced by spring physics.
- **Background aurora** uses CSS `transform: translate3d` keyframes only — no opacity changes that would force repaints.
- **Cursor** uses a single rAF loop with lerp smoothing; early-exits when the mouse hasn't moved.
- **Canvas particles** are FPS-capped (60 desktop / 30 mobile) and paused via `IntersectionObserver` when the canvas is off-screen.

---

## Deployment

### Vercel (recommended)

```bash
npx vercel
```

Vercel auto-detects Next.js. The model weight files in `public/model/` are served as static assets from Vercel's CDN and cached by the browser after first download.

### Environment variables

No environment variables are required. The model is served entirely as static assets.

---

## Project Info

| Field | Value |
|---|---|
| Course | ICT 120 — Intelligent Systems |
| Section | BSCS 3B |
| Dataset | CIFAR-10 (Krizhevsky, 2009) |
| Model | Custom CNN trained from scratch |
| Frontend | Next.js 15 · TypeScript · Tailwind · Framer Motion |
| Inference | In-browser · TensorFlow.js 4.22 · WebGL |

---

> *"This doesn't look like a student project."*
> That was the goal.
