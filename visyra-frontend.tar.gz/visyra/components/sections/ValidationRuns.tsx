"use client";
import { motion } from "framer-motion";
import { CheckCircle2, Clock, Percent } from "lucide-react";
import { validationRuns } from "@/mock-data";
import { CIFAR10_CLASSES } from "@/constants/cifar10";

const EXTRA_RUNS = [
  { id: 6, className: "Frog",    confidence: 83.1, inferenceMs: 11.8, status: "correct", emoji: "🐸" },
  { id: 7, className: "Truck",   confidence: 77.4, inferenceMs: 13.5, status: "correct", emoji: "🚛" },
  { id: 8, className: "Bird",    confidence: 62.7, inferenceMs: 12.0, status: "correct", emoji: "🐦" },
  { id: 9, className: "Deer",    confidence: 58.2, inferenceMs: 14.9, status: "misclass", emoji: "🦌" },
  { id: 10, className: "Car",    confidence: 89.3, inferenceMs: 11.1, status: "correct", emoji: "🚗" },
];

const ALL_RUNS = [...validationRuns, ...EXTRA_RUNS];

// Per-class accuracy (mock)
const perClass: Record<string, number> = {
  Airplane:    83.4, Automobile: 89.2, Bird: 74.2, Cat:   70.2,
  Deer:        79.6, Dog:        79.4, Frog: 83.6, Horse: 85.6,
  Ship:        87.6, Truck:      87.0,
};

export default function ValidationRuns() {
  return (
    <section id="validation" className="py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <span className="text-xs font-semibold tracking-[0.15em] uppercase text-violet-500 mb-3 block">
            Validation Runs
          </span>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-zinc-900 mb-4">
            5 Sample Validations
          </h2>
          <p className="text-zinc-500 max-w-md mx-auto">
            Each class run through the model with one representative sample — verifying real-world prediction behavior.
          </p>
        </motion.div>

        {/* Primary 5 runs */}
        <div className="grid md:grid-cols-5 gap-3 mb-12">
          {validationRuns.map((run, i) => (
            <motion.div
              key={run.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              whileHover={{ y: -6, boxShadow: "0 12px 40px rgba(124,58,237,0.18)" }}
              className="glass rounded-3xl p-5 flex flex-col items-center gap-3 text-center transition-all duration-300 cursor-default"
              style={{ boxShadow: "0 2px 20px rgba(124,58,237,0.07)" }}
            >
              {/* Emoji */}
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl"
                style={{
                  background: "linear-gradient(135deg, rgba(124,58,237,0.1), rgba(91,33,182,0.05))",
                  boxShadow: "0 0 20px rgba(124,58,237,0.15)",
                }}
              >
                {run.emoji}
              </div>

              <div>
                <p className="font-bold text-zinc-900 text-sm">{run.className}</p>
                <p className="text-xs text-zinc-400 mt-0.5">Run #{run.id}</p>
              </div>

              {/* Confidence */}
              <div
                className="w-full rounded-xl py-2 px-3 text-center"
                style={{ background: "rgba(124,58,237,0.06)" }}
              >
                <span
                  className="text-xl font-bold"
                  style={{ color: run.confidence >= 85 ? "#10B981" : run.confidence >= 65 ? "#F59E0B" : "#EF4444" }}
                >
                  {run.confidence}%
                </span>
                <p className="text-[10px] text-zinc-400 mt-0.5">confidence</p>
              </div>

              {/* Meta */}
              <div className="flex items-center gap-2 text-[10px] text-zinc-400">
                <Clock size={10} /> {run.inferenceMs}ms
              </div>

              <div className="flex items-center gap-1.5">
                <CheckCircle2 size={12} className={run.status === "correct" ? "text-emerald-500" : "text-rose-400"} />
                <span className={`text-[10px] font-medium ${run.status === "correct" ? "text-emerald-600" : "text-rose-500"}`}>
                  {run.status === "correct" ? "Correct" : "Misclassified"}
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Per-class accuracy bars */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="glass rounded-3xl p-6 md:p-8"
          style={{ boxShadow: "0 4px 30px rgba(124,58,237,0.08)" }}
        >
          <p className="font-semibold text-zinc-900 mb-1">Per-Class Accuracy</p>
          <p className="text-xs text-zinc-400 mb-6">Recall across all 10 CIFAR-10 categories on the test set</p>
          <div className="grid md:grid-cols-2 gap-x-8 gap-y-3">
            {CIFAR10_CLASSES.map((cls, i) => (
              <motion.div
                key={cls.id}
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
                className="flex items-center gap-3"
              >
                <span className="text-base w-6 flex-shrink-0">{cls.emoji}</span>
                <span className="text-xs text-zinc-600 w-20 flex-shrink-0">{cls.name}</span>
                <div className="flex-1 h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${perClass[cls.name]}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
                    className="h-full rounded-full"
                    style={{ background: "linear-gradient(90deg, #7C3AED, #A78BFA)" }}
                  />
                </div>
                <span className="text-xs font-semibold text-zinc-500 w-10 text-right">
                  {perClass[cls.name]}%
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
