"use client";
import { motion } from "framer-motion";
import { CIFAR10_CLASSES } from "@/constants/cifar10";

const perClassAcc: Record<string, number> = {
  Airplane:    83.4, Automobile: 89.2, Bird: 74.2, Cat:   70.2,
  Deer:        79.6, Dog:        79.4, Frog: 83.6, Horse: 85.6,
  Ship:        87.6, Truck:      87.0,
};

export default function ClassGallery() {
  return (
    <section id="classes" className="py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <span className="text-xs font-semibold tracking-[0.15em] uppercase text-violet-500 mb-3 block">
            Dataset Classes
          </span>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-zinc-900 mb-4">
            CIFAR-10 Classes
          </h2>
          <p className="text-zinc-500 max-w-md mx-auto">
            10 object categories, 6,000 training images each — 60,000 tiny 32×32 images in total.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          {CIFAR10_CLASSES.map((cls, i) => {
            const acc = perClassAcc[cls.name];
            return (
              <motion.div
                key={cls.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.45, delay: i * 0.06 }}
                whileHover={{ y: -8, boxShadow: "0 16px 48px rgba(124,58,237,0.2)" }}
                className="glass rounded-3xl p-5 flex flex-col items-center gap-3 text-center cursor-default group transition-all duration-300"
                style={{ boxShadow: "0 2px 20px rgba(124,58,237,0.06)" }}
              >
                <motion.div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center text-4xl"
                  style={{
                    background: "linear-gradient(135deg, rgba(124,58,237,0.1), rgba(91,33,182,0.06))",
                  }}
                  whileHover={{ rotate: [0, -5, 5, 0] }}
                  transition={{ duration: 0.4 }}
                >
                  {cls.emoji}
                </motion.div>

                <div>
                  <p className="font-semibold text-zinc-900 text-sm">{cls.name}</p>
                  <p className="text-[10px] text-zinc-400 mt-0.5">{cls.desc}</p>
                </div>

                <div className="w-full">
                  <div className="flex justify-between text-[10px] text-zinc-400 mb-1">
                    <span>Recall</span>
                    <span className="font-semibold text-violet-600">{acc}%</span>
                  </div>
                  <div className="h-1 bg-zinc-100 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${acc}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.8, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] }}
                      className="h-full rounded-full"
                      style={{ background: "linear-gradient(90deg, #7C3AED, #A78BFA)" }}
                    />
                  </div>
                </div>

                {/* Class index badge */}
                <span
                  className="text-[10px] font-semibold px-2.5 py-0.5 rounded-full"
                  style={{
                    background: "rgba(124,58,237,0.08)",
                    color: "#7C3AED",
                  }}
                >
                  Class {cls.id}
                </span>
              </motion.div>
            );
          })}
        </div>

        {/* Dataset info strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-8 glass-dark rounded-3xl p-6 grid grid-cols-2 md:grid-cols-4 gap-6 text-center"
        >
          {[
            { label: "Total Images",    value: "60,000" },
            { label: "Training Set",    value: "50,000" },
            { label: "Test Set",        value: "10,000" },
            { label: "Image Size",      value: "32×32×3" },
          ].map(({ label, value }) => (
            <div key={label}>
              <p className="text-xl font-bold text-violet-700">{value}</p>
              <p className="text-xs text-zinc-500 mt-0.5">{label}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
