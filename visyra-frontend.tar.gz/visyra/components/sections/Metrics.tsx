"use client";
import { motion, useInView } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import { Target, Layers, Repeat2, BarChart3, Zap, Activity } from "lucide-react";
import { mockMetrics } from "@/mock-data";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid
} from "recharts";
import { trainingHistory } from "@/mock-data";

const METRICS = [
  { key: "testAccuracy", label: "Test Accuracy", icon: Target, suffix: "%", color: "#7C3AED", desc: "Overall correct classifications on held-out test set" },
  { key: "precision",    label: "Precision",     icon: Layers, suffix: "%", color: "#6D28D9", desc: "True positives / (true positives + false positives)" },
  { key: "recall",       label: "Recall",        icon: Repeat2, suffix: "%", color: "#5B21B6", desc: "True positives / (true positives + false negatives)" },
  { key: "f1Score",      label: "F1 Score",      icon: BarChart3, suffix: "%", color: "#7C3AED", desc: "Harmonic mean of precision and recall" },
  { key: "inferenceSpeed", label: "Inference",   icon: Zap, suffix: "ms", color: "#6D28D9", desc: "Average prediction time per image on CPU" },
  { key: "totalParams",  label: "Parameters",    icon: Activity, suffix: "", color: "#5B21B6", isString: true, desc: "Trainable weights in the CNN" },
];

function AnimatedNumber({ target, suffix, duration = 1200 }: { target: number; suffix: string; duration?: number }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    const steps = 50;
    const inc = target / steps;
    let cur = 0;
    const interval = setInterval(() => {
      cur += inc;
      if (cur >= target) { setVal(target); clearInterval(interval); }
      else setVal(cur);
    }, duration / steps);
    return () => clearInterval(interval);
  }, [inView, target, duration]);

  const display = Number.isInteger(target) ? Math.round(val).toString() : val.toFixed(1);
  return <span ref={ref}>{display}{suffix}</span>;
}

const chartData = trainingHistory.accuracy.map((acc, i) => ({
  epoch: i + 1,
  trainAcc: (acc * 100).toFixed(1),
  valAcc: (trainingHistory.valAccuracy[i] * 100).toFixed(1),
}));

export default function Metrics() {
  return (
    <section id="metrics" className="py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <span className="text-xs font-semibold tracking-[0.15em] uppercase text-violet-500 mb-3 block">
            Model Evaluation
          </span>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-zinc-900 mb-4">
            Performance Metrics
          </h2>
          <p className="text-zinc-500 max-w-md mx-auto">
            Trained for 20 epochs on 50,000 images. Evaluated on 10,000 held-out test images.
          </p>
        </motion.div>

        {/* Metric cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-10">
          {METRICS.map(({ key, label, icon: Icon, suffix, color, desc, isString }, i) => {
            const raw = mockMetrics[key as keyof typeof mockMetrics];
            return (
              <motion.div
                key={key}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                whileHover={{ y: -4, boxShadow: "0 8px 40px rgba(124,58,237,0.15)" }}
                className="glass rounded-3xl p-5 cursor-default transition-all duration-300"
                style={{ boxShadow: "0 2px 20px rgba(124,58,237,0.06)" }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{
                      background: `linear-gradient(135deg, ${color}18, ${color}0a)`,
                      boxShadow: `0 0 16px ${color}22`,
                    }}
                  >
                    <Icon size={18} style={{ color }} />
                  </div>
                </div>
                <p className="text-2xl md:text-3xl font-bold text-zinc-900 mb-1">
                  {isString ? (
                    <span>{String(raw)}</span>
                  ) : (
                    <AnimatedNumber target={Number(raw)} suffix={suffix} />
                  )}
                </p>
                <p className="text-xs font-semibold text-zinc-500">{label}</p>
                <p className="text-xs text-zinc-400 mt-1 leading-snug hidden md:block">{desc}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Training curve chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="glass rounded-3xl p-6"
          style={{ boxShadow: "0 2px 30px rgba(124,58,237,0.08)" }}
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="font-semibold text-zinc-900">Training History</p>
              <p className="text-xs text-zinc-400 mt-0.5">Accuracy over 20 epochs</p>
            </div>
            <div className="flex items-center gap-4 text-xs text-zinc-500">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 rounded bg-violet-600 inline-block" />Train
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 rounded bg-violet-300 inline-block" />Validation
              </span>
            </div>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid stroke="rgba(124,58,237,0.06)" strokeDasharray="3 3" />
                <XAxis dataKey="epoch" tick={{ fontSize: 11, fill: "#A1A1AA" }} tickLine={false} axisLine={false} />
                <YAxis domain={[40, 85]} tick={{ fontSize: 11, fill: "#A1A1AA" }} tickLine={false} axisLine={false} tickFormatter={(v) => `${v}%`} />
                <Tooltip
                  contentStyle={{
                    background: "rgba(255,255,255,0.9)",
                    border: "1px solid rgba(124,58,237,0.15)",
                    borderRadius: "12px",
                    fontSize: "12px",
                    boxShadow: "0 4px 20px rgba(124,58,237,0.12)",
                  }}
                  formatter={(v) => [`${v}%`]}
                />
                <Line type="monotone" dataKey="trainAcc" stroke="#7C3AED" strokeWidth={2.5} dot={false} name="Train Acc" />
                <Line type="monotone" dataKey="valAcc" stroke="#C4B5FD" strokeWidth={2} dot={false} strokeDasharray="4 2" name="Val Acc" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
