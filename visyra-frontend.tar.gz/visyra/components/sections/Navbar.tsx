"use client";
import { motion } from "framer-motion";
import { Brain } from "lucide-react";

const navLinks = [
  { label: "Predict", href: "#predict" },
  { label: "Metrics", href: "#metrics" },
  { label: "Matrix", href: "#matrix" },
  { label: "Validation", href: "#validation" },
  { label: "Classes", href: "#classes" },
];

export default function Navbar() {
  return (
    <motion.nav
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="fixed top-0 left-0 right-0 z-50"
    >
      <div className="mx-auto max-w-6xl px-6 pt-4">
        <div
          className="glass rounded-2xl px-6 py-3 flex items-center justify-between"
          style={{
            boxShadow: "0 4px 24px rgba(124,58,237,0.08), 0 1px 2px rgba(0,0,0,0.04)",
          }}
        >
          {/* Logo */}
          <a href="#" className="flex items-center gap-2.5 group">
            <div
              className="w-8 h-8 rounded-xl flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg, #7C3AED, #5B21B6)",
                boxShadow: "0 0 20px rgba(124,58,237,0.35)",
              }}
            >
              <Brain size={16} className="text-white" />
            </div>
            <span
              className="text-lg font-semibold tracking-tight"
              style={{ color: "#0A0A0F" }}
            >
              Visyra
            </span>
          </a>

          {/* Nav links */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="px-4 py-1.5 text-sm font-medium rounded-xl transition-all duration-200 text-zinc-500 hover:text-violet-700 hover:bg-violet-50"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CTA */}
          <a
            href="#predict"
            className="hidden md:block text-sm font-semibold px-5 py-2 rounded-xl text-white transition-all duration-200 hover:scale-105"
            style={{
              background: "linear-gradient(135deg, #7C3AED, #5B21B6)",
              boxShadow: "0 0 20px rgba(124,58,237,0.3)",
            }}
          >
            Try it free
          </a>
        </div>
      </div>
    </motion.nav>
  );
}
