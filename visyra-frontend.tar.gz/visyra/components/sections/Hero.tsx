"use client";
import { motion } from "framer-motion";
import { ArrowRight, Cpu, Zap, Target } from "lucide-react";

const badges = [
  { icon: Cpu, label: "CNN Architecture" },
  { icon: Zap, label: "12ms Inference" },
  { icon: Target, label: "78.4% Accuracy" },
];

export default function Hero() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-6 pt-32 pb-20 text-center">
      {/* Pill badge */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="inline-flex items-center gap-2 glass-dark rounded-full px-4 py-1.5 mb-8"
      >
        <span
          className="w-2 h-2 rounded-full animate-pulse-glow"
          style={{ background: "#7C3AED" }}
        />
        <span className="text-xs font-medium text-violet-700 tracking-wide uppercase">
          CIFAR-10 Deep Learning Research Platform
        </span>
      </motion.div>

      {/* Headline */}
      <motion.h1
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.35 }}
        className="max-w-4xl text-5xl md:text-7xl font-bold leading-tight tracking-tight mb-6"
        style={{ color: "#0A0A0F" }}
      >
        See{" "}
        <span
          className="relative"
          style={{
            background: "linear-gradient(135deg, #7C3AED, #5B21B6, #A78BFA)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          What AI Sees
        </span>
      </motion.h1>

      {/* Sub */}
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
        className="max-w-xl text-lg md:text-xl text-zinc-500 leading-relaxed mb-10"
      >
        A convolutional neural network trained on 60,000 images across 10 object classes.
        Upload any image and watch deep learning come to life.
      </motion.p>

      {/* CTA buttons */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.62 }}
        className="flex flex-wrap gap-4 justify-center mb-16"
      >
        <a
          href="#predict"
          className="group flex items-center gap-2 text-white font-semibold px-7 py-3.5 rounded-2xl transition-all duration-200 hover:scale-105"
          style={{
            background: "linear-gradient(135deg, #7C3AED, #5B21B6)",
            boxShadow: "0 0 30px rgba(124,58,237,0.4), 0 4px 16px rgba(124,58,237,0.2)",
          }}
        >
          Try a Prediction
          <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform duration-200" />
        </a>
        <a
          href="#metrics"
          className="flex items-center gap-2 text-zinc-600 font-semibold px-7 py-3.5 rounded-2xl glass transition-all duration-200 hover:scale-105 hover:text-violet-700"
          style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}
        >
          View Metrics
        </a>
      </motion.div>

      {/* Stat badges */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.75 }}
        className="flex flex-wrap gap-3 justify-center"
      >
        {badges.map(({ icon: Icon, label }) => (
          <div
            key={label}
            className="glass flex items-center gap-2 px-4 py-2 rounded-xl"
            style={{ boxShadow: "0 2px 12px rgba(124,58,237,0.08)" }}
          >
            <Icon size={14} className="text-violet-600" />
            <span className="text-xs font-medium text-zinc-600">{label}</span>
          </div>
        ))}
      </motion.div>

      {/* Scroll hint */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-xs text-zinc-400 tracking-widest uppercase">Scroll</span>
        <div className="w-px h-8 bg-gradient-to-b from-violet-300 to-transparent" />
      </motion.div>
    </section>
  );
}
