"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { confusionMatrix } from "@/mock-data";
import { CIFAR10_CLASSES } from "@/constants/cifar10";

function getColor(value: number, max: number, isMain: boolean): string {
  const intensity = value / max;
  if (isMain) {
    return `rgba(124,58,237,${0.15 + intensity * 0.85})`;
  }
  if (intensity > 0.3) return `rgba(239,68,68,${intensity * 0.6})`;
  if (intensity > 0.1) return `rgba(245,158,11,${intensity * 0.5})`;
  return `rgba(124,58,237,${intensity * 0.2})`;
}

export default function ConfusionMatrix() {
  const [hovered, setHovered] = useState<{ row: number; col: number } | null>(null);

  const rowMax = confusionMatrix.map((row) => Math.max(...row));
  const absMax = Math.max(...confusionMatrix.flat());

  const hoveredInfo = hovered
    ? {
        actual: CIFAR10_CLASSES[hovered.row].name,
        predicted: CIFAR10_CLASSES[hovered.col].name,
        value: confusionMatrix[hovered.row][hovered.col],
        correct: hovered.row === hovered.col,
        rowTotal: confusionMatrix[hovered.row].reduce((a, b) => a + b, 0),
      }
    : null;

  return (
    <section id="matrix" className="py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <span className="text-xs font-semibold tracking-[0.15em] uppercase text-violet-500 mb-3 block">
            Confusion Matrix
          </span>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-zinc-900 mb-4">
            Where the Model Thinks
          </h2>
          <p className="text-zinc-500 max-w-md mx-auto">
            Hover any cell to see exactly what the model predicted vs. the ground truth. Diagonal = correct.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="glass rounded-3xl p-4 md:p-8 overflow-x-auto"
          style={{ boxShadow: "0 4px 40px rgba(124,58,237,0.1)" }}
        >
          {/* Hover tooltip */}
          <div className="mb-5 min-h-10 flex items-center justify-center">
            {hoveredInfo ? (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass-dark rounded-2xl px-4 py-2 text-sm text-center"
              >
                {hoveredInfo.correct ? (
                  <span className="text-emerald-600 font-medium">
                    ✓ Correctly predicted{" "}
                    <span className="font-bold">{hoveredInfo.actual}</span>
                    {" "}— {hoveredInfo.value} samples
                    {" "}({((hoveredInfo.value / hoveredInfo.rowTotal) * 100).toFixed(0)}% recall)
                  </span>
                ) : (
                  <span className="text-rose-500 font-medium">
                    Actual <span className="font-bold">{hoveredInfo.actual}</span>
                    {" "}→ predicted as <span className="font-bold">{hoveredInfo.predicted}</span>
                    {" "}— {hoveredInfo.value} misclassifications
                  </span>
                )}
              </motion.div>
            ) : (
              <span className="text-xs text-zinc-400">Hover a cell to inspect predictions</span>
            )}
          </div>

          <div className="min-w-[520px]">
            {/* Predicted labels header */}
            <div className="flex mb-1 ml-[68px]">
              {CIFAR10_CLASSES.map((cls) => (
                <div
                  key={cls.id}
                  className="flex-1 flex flex-col items-center gap-0.5"
                  title={cls.name}
                >
                  <span className="text-sm">{cls.emoji}</span>
                  <span className="text-[9px] text-zinc-400 leading-none">{cls.name.slice(0, 4)}</span>
                </div>
              ))}
            </div>

            {/* Matrix rows */}
            {confusionMatrix.map((row, rowIdx) => (
              <motion.div
                key={rowIdx}
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: rowIdx * 0.04 }}
                className="flex items-center mb-0.5"
              >
                {/* Row label */}
                <div className="w-16 flex-shrink-0 flex items-center gap-1.5 pr-2">
                  <span className="text-sm">{CIFAR10_CLASSES[rowIdx].emoji}</span>
                  <span className="text-[9px] text-zinc-400 leading-none">{CIFAR10_CLASSES[rowIdx].name.slice(0, 4)}</span>
                </div>

                {/* Cells */}
                {row.map((val, colIdx) => {
                  const isMain = rowIdx === colIdx;
                  const isHov = hovered?.row === rowIdx && hovered?.col === colIdx;
                  return (
                    <div
                      key={colIdx}
                      className="flex-1 aspect-square flex items-center justify-center rounded text-xs font-semibold cursor-pointer transition-all duration-200 m-px"
                      style={{
                        background: getColor(val, isMain ? rowMax[rowIdx] : absMax, isMain),
                        color: isMain && val > 600 ? "white" : "#0A0A0F",
                        transform: isHov ? "scale(1.15)" : "scale(1)",
                        boxShadow: isHov ? "0 0 12px rgba(124,58,237,0.4)" : "none",
                        zIndex: isHov ? 2 : 0,
                        position: "relative",
                        fontSize: "0.65rem",
                      }}
                      onMouseEnter={() => setHovered({ row: rowIdx, col: colIdx })}
                      onMouseLeave={() => setHovered(null)}
                    >
                      {val > 0 ? val : ""}
                    </div>
                  );
                })}
              </motion.div>
            ))}

            {/* Legend */}
            <div className="flex items-center gap-6 mt-6 flex-wrap justify-center text-xs text-zinc-400">
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 rounded" style={{ background: "rgba(124,58,237,0.7)" }} />
                Correct (diagonal)
              </span>
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 rounded" style={{ background: "rgba(239,68,68,0.4)" }} />
                High error
              </span>
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 rounded" style={{ background: "rgba(124,58,237,0.05)" }} />
                Low error
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
