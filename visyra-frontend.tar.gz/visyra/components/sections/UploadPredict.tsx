"use client";
import { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload, Image as ImageIcon, RefreshCcw, CheckCircle2, ChevronDown, ChevronUp
} from "lucide-react";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer } from "recharts";
import { CIFAR10_CLASSES } from "@/constants/cifar10";
import { mockPredictionResults } from "@/mock-data";

const SAMPLE_IMAGES = [
  { label: "Airplane", emoji: "✈️", id: 0 },
  { label: "Dog",      emoji: "🐶", id: 5 },
  { label: "Cat",      emoji: "🐱", id: 3 },
  { label: "Ship",     emoji: "🚢", id: 8 },
  { label: "Horse",    emoji: "🐴", id: 7 },
  { label: "Truck",    emoji: "🚛", id: 9 },
];

function randomPrediction(classId?: number) {
  const cls = classId !== undefined ? CIFAR10_CLASSES[classId] : CIFAR10_CLASSES[Math.floor(Math.random() * 10)];
  const scores = CIFAR10_CLASSES.map((c) => {
    if (c.id === cls.id) return Math.floor(Math.random() * 15 + 75);
    return Math.floor(Math.random() * 10 + 1);
  });
  const total = scores.reduce((a, b) => a + b, 0);
  const normalized = scores.map((s) => parseFloat(((s / total) * 100).toFixed(1)));
  return { ...cls, allScores: normalized, confidence: normalized[cls.id] };
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const LOADING_MESSAGES = [
  "Reading image pixels…",
  "Extracting feature maps…",
  "Propagating through conv layers…",
  "Applying softmax…",
  "Finalizing prediction…",
];

export default function UploadPredict() {
  const [dragOver, setDragOver] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadMsg, setLoadMsg] = useState(0);
  const [result, setResult] = useState<ReturnType<typeof randomPrediction> | null>(null);
  const [showAllScores, setShowAllScores] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
      setResult(null);
    };
    reader.readAsDataURL(file);
  }, []);

  const runInference = useCallback(async (classId?: number) => {
    setLoading(true);
    setResult(null);
    for (let i = 0; i < LOADING_MESSAGES.length; i++) {
      setLoadMsg(i);
      await sleep(480);
    }
    setResult(randomPrediction(classId));
    setLoading(false);
  }, []);

  const handleSample = useCallback((sample: typeof SAMPLE_IMAGES[number]) => {
    setPreview(null);
    setResult(null);
    runInference(sample.id);
  }, [runInference]);

  const radarData = result
    ? CIFAR10_CLASSES.map((c) => ({ subject: c.name, value: result.allScores[c.id] }))
    : [];

  return (
    <section id="predict" className="py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <span className="text-xs font-semibold tracking-[0.15em] uppercase text-violet-500 mb-3 block">
            Neural Inference
          </span>
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight text-zinc-900 mb-4">
            Classify an Image
          </h2>
          <p className="text-zinc-500 max-w-md mx-auto">
            Upload any image or pick a sample. The CNN will predict which of 10 CIFAR-10 classes it belongs to.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Upload zone */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="flex flex-col gap-4"
          >
            {/* Dropzone */}
            <div
              className={`relative rounded-3xl border-2 border-dashed transition-all duration-300 cursor-pointer flex flex-col items-center justify-center min-h-56 p-8
                ${dragOver
                  ? "border-violet-500 bg-violet-50 scale-[1.01]"
                  : "border-violet-200 bg-white/50 hover:border-violet-400 hover:bg-violet-50/40"
                }`}
              style={{ backdropFilter: "blur(12px)" }}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                const file = e.dataTransfer.files[0];
                if (file) handleFile(file);
              }}
              onClick={() => inputRef.current?.click()}
            >
              <input
                ref={inputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
              />
              {preview ? (
                <div className="flex flex-col items-center gap-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={preview}
                    alt="Uploaded preview"
                    className="w-32 h-32 object-cover rounded-2xl shadow-lg"
                  />
                  <span className="text-sm text-zinc-500">Click to change image</span>
                </div>
              ) : (
                <>
                  <div
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 transition-all duration-300 ${dragOver ? "scale-110" : ""}`}
                    style={{
                      background: "linear-gradient(135deg, rgba(124,58,237,0.12), rgba(91,33,182,0.08))",
                      boxShadow: "0 0 24px rgba(124,58,237,0.15)",
                    }}
                  >
                    <Upload size={24} className="text-violet-600" />
                  </div>
                  <p className="font-semibold text-zinc-700 mb-1">Drop your image here</p>
                  <p className="text-sm text-zinc-400">or click to browse · JPG, PNG, WebP</p>
                </>
              )}
            </div>

            {/* Predict button */}
            {preview && !loading && (
              <motion.button
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => runInference()}
                className="w-full py-3.5 rounded-2xl text-white font-semibold text-sm transition-all"
                style={{
                  background: "linear-gradient(135deg, #7C3AED, #5B21B6)",
                  boxShadow: "0 0 30px rgba(124,58,237,0.35)",
                }}
              >
                Run Inference
              </motion.button>
            )}

            {/* Sample images */}
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-zinc-400 mb-3">
                Or try a sample
              </p>
              <div className="grid grid-cols-3 gap-2">
                {SAMPLE_IMAGES.map((s) => (
                  <motion.button
                    key={s.id}
                    whileHover={{ scale: 1.04, y: -2 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => handleSample(s)}
                    className="glass rounded-2xl py-3 flex flex-col items-center gap-1.5 hover:border-violet-300 transition-all duration-200"
                    style={{ boxShadow: "0 2px 12px rgba(124,58,237,0.06)" }}
                  >
                    <span className="text-xl">{s.emoji}</span>
                    <span className="text-xs font-medium text-zinc-600">{s.label}</span>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Result panel */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative"
          >
            <AnimatePresence mode="wait">
              {/* Loading */}
              {loading && (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0, scale: 0.97 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.97 }}
                  className="glass rounded-3xl p-8 h-full min-h-80 flex flex-col items-center justify-center gap-6"
                  style={{ boxShadow: "0 0 40px rgba(124,58,237,0.1)" }}
                >
                  {/* Neural orbit animation */}
                  <div className="relative w-20 h-20 flex items-center justify-center">
                    <div
                      className="absolute inset-0 rounded-full animate-spin"
                      style={{
                        border: "2px solid transparent",
                        borderTop: "2px solid #7C3AED",
                        animationDuration: "1.2s",
                      }}
                    />
                    <div
                      className="absolute inset-2 rounded-full animate-spin"
                      style={{
                        border: "2px solid transparent",
                        borderBottom: "2px solid #A78BFA",
                        animationDuration: "0.8s",
                        animationDirection: "reverse",
                      }}
                    />
                    <div
                      className="w-4 h-4 rounded-full animate-pulse-glow"
                      style={{ background: "linear-gradient(135deg, #7C3AED, #5B21B6)" }}
                    />
                  </div>
                  <div className="text-center">
                    <p className="font-semibold text-zinc-700 mb-1 text-sm">
                      {LOADING_MESSAGES[loadMsg]}
                    </p>
                    <p className="text-xs text-zinc-400">CNN processing…</p>
                  </div>
                </motion.div>
              )}

              {/* Result */}
              {result && !loading && (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="glass rounded-3xl p-6 flex flex-col gap-5"
                  style={{ boxShadow: "0 0 50px rgba(124,58,237,0.12)" }}
                >
                  {/* Top result */}
                  <div className="flex items-center gap-4">
                    <div
                      className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl"
                      style={{
                        background: "linear-gradient(135deg, rgba(124,58,237,0.1), rgba(91,33,182,0.06))",
                        boxShadow: "0 0 24px rgba(124,58,237,0.2)",
                      }}
                    >
                      {result.emoji}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <CheckCircle2 size={14} className="text-emerald-500" />
                        <span className="text-xs text-emerald-600 font-medium">Classified</span>
                      </div>
                      <p className="text-2xl font-bold text-zinc-900">{result.name}</p>
                      <p className="text-xs text-zinc-400 mt-0.5">{result.desc}</p>
                    </div>
                    <div className="text-right">
                      <CountUp target={result.confidence} suffix="%" className="text-3xl font-bold text-violet-600" />
                      <p className="text-xs text-zinc-400 mt-0.5">confidence</p>
                    </div>
                  </div>

                  {/* Confidence bar */}
                  <div>
                    <div className="flex justify-between text-xs text-zinc-400 mb-1.5">
                      <span>Confidence</span>
                      <span>{result.confidence.toFixed(1)}%</span>
                    </div>
                    <div className="h-2 bg-zinc-100 rounded-full overflow-hidden">
                      <MotionBar pct={result.confidence} />
                    </div>
                  </div>

                  {/* Radar chart */}
                  <div className="h-44">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={radarData}>
                        <PolarGrid stroke="rgba(124,58,237,0.1)" />
                        <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fill: "#71717A" }} />
                        <Radar
                          name="Confidence"
                          dataKey="value"
                          stroke="#7C3AED"
                          fill="#7C3AED"
                          fillOpacity={0.15}
                          strokeWidth={2}
                        />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>

                  {/* All scores collapsible */}
                  <button
                    onClick={() => setShowAllScores(!showAllScores)}
                    className="flex items-center gap-1.5 text-xs text-violet-600 font-medium hover:text-violet-800 transition-colors"
                  >
                    {showAllScores ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                    {showAllScores ? "Hide" : "Show"} all class scores
                  </button>

                  <AnimatePresence>
                    {showAllScores && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="flex flex-col gap-1.5">
                          {CIFAR10_CLASSES.map((cls) => (
                            <div key={cls.id} className="flex items-center gap-2">
                              <span className="text-sm w-5">{cls.emoji}</span>
                              <span className="text-xs text-zinc-500 w-20">{cls.name}</span>
                              <div className="flex-1 h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                                <MotionBar pct={result.allScores[cls.id]} highlight={cls.id === result.id} delay={cls.id * 40} />
                              </div>
                              <span className="text-xs text-zinc-400 w-10 text-right">{result.allScores[cls.id].toFixed(1)}%</span>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Retry */}
                  <button
                    onClick={() => { setResult(null); setPreview(null); }}
                    className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-violet-600 transition-colors"
                  >
                    <RefreshCcw size={12} /> Try another image
                  </button>
                </motion.div>
              )}

              {/* Empty */}
              {!loading && !result && (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="glass rounded-3xl p-8 h-full min-h-80 flex flex-col items-center justify-center gap-4 text-center"
                >
                  <div
                    className="w-16 h-16 rounded-2xl flex items-center justify-center"
                    style={{
                      background: "linear-gradient(135deg, rgba(124,58,237,0.08), rgba(91,33,182,0.04))",
                    }}
                  >
                    <ImageIcon size={28} className="text-violet-300" />
                  </div>
                  <p className="text-zinc-400 text-sm">
                    Upload an image or choose a sample to see the prediction result here.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// Animated bar
function MotionBar({ pct, highlight = true, delay = 0 }: { pct: number; highlight?: boolean; delay?: number }) {
  return (
    <motion.div
      initial={{ width: 0 }}
      animate={{ width: `${pct}%` }}
      transition={{ duration: 0.8, delay: delay / 1000, ease: [0.22, 1, 0.36, 1] }}
      className="h-full rounded-full"
      style={{
        background: highlight
          ? "linear-gradient(90deg, #7C3AED, #A78BFA)"
          : "rgba(124,58,237,0.35)",
      }}
    />
  );
}

// Count-up number
function CountUp({ target, suffix = "", className = "" }: { target: number; suffix?: string; className?: string }) {
  const [val, setVal] = useState(0);
  const [mounted, setMounted] = useState(false);

  const start = useCallback(() => {
    setMounted(true);
    const duration = 900;
    const steps = 40;
    const inc = target / steps;
    let cur = 0;
    const interval = setInterval(() => {
      cur += inc;
      if (cur >= target) { setVal(target); clearInterval(interval); }
      else setVal(cur);
    }, duration / steps);
    return () => clearInterval(interval);
  }, [target]);

  if (!mounted) {
    // trigger on next tick
    setTimeout(start, 50);
  }

  return <span className={className}>{val.toFixed(1)}{suffix}</span>;
}
