import Background from "@/components/Background";
import Navbar from "@/components/sections/Navbar";
import Hero from "@/components/sections/Hero";
import UploadPredict from "@/components/sections/UploadPredict";
import Metrics from "@/components/sections/Metrics";
import ConfusionMatrix from "@/components/sections/ConfusionMatrix";
import ValidationRuns from "@/components/sections/ValidationRuns";
import ClassGallery from "@/components/sections/ClassGallery";

export default function Home() {
  return (
    <>
      <Background />
      <Navbar />
      <main>
        <Hero />
        <UploadPredict />
        <Metrics />
        <ConfusionMatrix />
        <ValidationRuns />
        <ClassGallery />
      </main>

      <footer className="py-10 px-6 text-center">
        <div className="max-w-5xl mx-auto border-t border-violet-100 pt-8">
          <p className="text-xs text-zinc-400">
            Visyra · CIFAR-10 Image Classification ·{" "}
            <span className="text-violet-500">ICT 120 Final Project</span>
          </p>
          <p className="text-xs text-zinc-300 mt-1">
            Built with Next.js, TensorFlow/Keras, FastAPI
          </p>
        </div>
      </footer>
    </>
  );
}
