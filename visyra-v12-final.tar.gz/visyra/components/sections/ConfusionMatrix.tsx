"use client";
import { useState, useRef, useCallback, useEffect } from "react";
import SectionHeader from "@/components/SectionHeader";
import { motion, AnimatePresence } from "framer-motion";
import { confusionMatrix } from "@/mock-data";
import { CIFAR10_CLASSES } from "@/constants/cifar10";

function cellBg(v: number, max: number, isMain: boolean): string {
  const t = v / max;
  if (isMain)   return `rgba(124,58,237,${(0.10 + t * 0.90).toFixed(3)})`;
  if (t > 0.28) return `rgba(220,38,38,${(t * 0.55).toFixed(3)})`;
  if (t > 0.09) return `rgba(245,158,11,${(t * 0.48).toFixed(3)})`;
  return `rgba(124,58,237,${(t * 0.14).toFixed(3)})`;
}

interface HovCell { r: number; c: number }
interface TooltipPos { x: number; y: number }

// Tooltip dimensions — used for viewport clamping
const TT_W = 320;
const TT_H = 48;
const TT_OFFSET_Y = 18; // gap between cursor and tooltip
const TT_MARGIN    = 12; // min distance from viewport edge

export default function ConfusionMatrixSection() {
  const [hov, setHov]       = useState<HovCell | null>(null);
  const [pos, setPos]       = useState<TooltipPos>({ x: 0, y: 0 });
  const posRef              = useRef<TooltipPos>({ x: 0, y: 0 });
  const targetRef           = useRef<TooltipPos>({ x: 0, y: 0 });
  const rafRef              = useRef<number>(0);
  const sectionRef          = useRef<HTMLElement>(null);
  const rowMax              = confusionMatrix.map(r => Math.max(...r));

  // Smooth tooltip position via lerp on a rAF loop
  // This keeps the tooltip from snapping — it drifts toward the cursor.
  useEffect(() => {
    const LERP = 0.18; // snappy but not instant

    const tick = () => {
      rafRef.current = requestAnimationFrame(tick);
      const tx = targetRef.current.x;
      const ty = targetRef.current.y;
      const px = posRef.current.x;
      const py = posRef.current.y;
      const dx = tx - px, dy = ty - py;
      if (Math.abs(dx) < 0.3 && Math.abs(dy) < 0.3) return;
      posRef.current = { x: px + dx * LERP, y: py + dy * LERP };
      setPos({ ...posRef.current });
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  // Track mouse position relative to the viewport, clamp to viewport edges
  const onMouseMove = useCallback((e: React.MouseEvent) => {
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    // Tooltip appears above the cursor by default
    let x = e.clientX - TT_W / 2;
    let y = e.clientY - TT_H - TT_OFFSET_Y;

    // Flip below cursor if too close to top
    if (y < TT_MARGIN) {
      y = e.clientY + TT_OFFSET_Y;
    }

    // Clamp horizontally
    x = Math.max(TT_MARGIN, Math.min(vw - TT_W - TT_MARGIN, x));
    // Clamp vertically (bottom edge)
    y = Math.min(vh - TT_H - TT_MARGIN, y);

    targetRef.current = { x, y };
  }, []);

  const onMouseLeave = useCallback(() => {
    setHov(null);
  }, []);

  const info = hov ? {
    actual: CIFAR10_CLASSES[hov.r].name,
    pred:   CIFAR10_CLASSES[hov.c].name,
    val:    confusionMatrix[hov.r][hov.c],
    ok:     hov.r === hov.c,
    total:  confusionMatrix[hov.r].reduce((a, b) => a + b, 0),
  } : null;

  return (
    <section
      id="matrix"
      ref={sectionRef}
      style={{ padding: "48px 20px" }}
      onMouseMove={onMouseMove}
      onMouseLeave={onMouseLeave}
    >
      {/* ── Floating cursor-tracking tooltip ─────────────────────────── */}
      {/* Rendered in a portal-like fixed layer so it's never clipped */}
      <AnimatePresence>
        {info && (
          <motion.div
            key="floating-tip"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.96 }}
            transition={{ duration: 0.12, ease: [0.22, 1, 0.36, 1] }}
            style={{
              position: "fixed",
              left: pos.x,
              top:  pos.y,
              width: TT_W,
              zIndex: 9000,
              pointerEvents: "none",
              // Visual
              background: info.ok ? "rgba(255,255,255,0.96)" : "rgba(255,255,255,0.96)",
              border: `1px solid ${info.ok ? "rgba(16,185,129,0.25)" : "rgba(239,68,68,0.22)"}`,
              borderRadius: 12,
              padding: "8px 16px",
              boxShadow: `0 8px 28px rgba(0,0,0,0.10), 0 2px 8px rgba(0,0,0,0.06),
                          0 0 0 1px ${info.ok ? "rgba(16,185,129,0.08)" : "rgba(239,68,68,0.06)"}`,
              backdropFilter: "blur(12px)",
              WebkitBackdropFilter: "blur(12px)",
              // Keep it on the compositor
              willChange: "transform",
            }}
          >
            {/* Colour indicator strip */}
            <div style={{
              position: "absolute",
              left: 0, top: 0, bottom: 0,
              width: 4,
              borderRadius: "12px 0 0 12px",
              background: info.ok
                ? "linear-gradient(180deg,#10b981,#059669)"
                : "linear-gradient(180deg,#ef4444,#dc2626)",
            }}/>

            <div style={{
              paddingLeft: 8,
              display: "flex",
              alignItems: "center",
              gap: 8,
            }}>
              <span style={{ fontSize: 15 }}>
                {info.ok
                  ? CIFAR10_CLASSES[hov!.r].emoji
                  : `${CIFAR10_CLASSES[hov!.r].emoji}→${CIFAR10_CLASSES[hov!.c].emoji}`}
              </span>
              <div>
                <p style={{
                  fontSize: 12,
                  fontWeight: 600,
                  color: info.ok ? "#059669" : "#dc2626",
                  lineHeight: 1.35,
                  fontFamily: "-apple-system,'SF Pro Text','Inter',sans-serif",
                }}>
                  {info.ok
                    ? `✓ ${info.actual} correctly predicted`
                    : `${info.actual} misclassified as ${info.pred}`}
                </p>
                <p style={{
                  fontSize: 11,
                  color: "#94a3b8",
                  lineHeight: 1.3,
                  fontFamily: "-apple-system,'SF Pro Text','Inter',sans-serif",
                }}>
                  {info.val.toLocaleString()} samples
                  {info.ok
                    ? ` · ${((info.val / info.total) * 100).toFixed(0)}% recall`
                    : ` · ${((info.val / info.total) * 100).toFixed(1)}% error rate`}
                </p>
              </div>
              <div style={{
                marginLeft: "auto",
                fontSize: 16,
                fontWeight: 800,
                color: info.ok ? "#059669" : "#dc2626",
                letterSpacing: "-0.02em",
                fontFamily: "-apple-system,'SF Pro Text','Inter',sans-serif",
              }}>
                {info.val}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div style={{ maxWidth: 1040, margin: "0 auto" }}>
        <SectionHeader
          tag="Confusion Matrix"
          title="Where the Model Thinks"
          sub="Rows = actual class · Columns = predicted class · Diagonal = correct predictions. Hover any cell."
        />

        {/* Static hint line — replaces the old fixed panel */}
        <p style={{
          fontSize: 12,
          color: "#94a3b8",
          marginBottom: 14,
          fontFamily: "-apple-system,'SF Pro Text','Inter',sans-serif",
        }}>
          {hov ? "\u00a0" : "Move cursor over any cell to inspect →"}
        </p>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.52 }}
          style={{
            background: "#ffffff",
            border: "1px solid rgba(0,0,0,0.07)",
            borderRadius: 22,
            padding: "20px 18px 18px",
            boxShadow: "0 4px 20px rgba(0,0,0,0.05)",
            overflowX: "auto",
            overflowY: "visible",
          }}
        >
          <div style={{ minWidth: 500 }}>
            {/* Column headers */}
            <div style={{ display: "flex", marginLeft: 62, marginBottom: 4 }}>
              {CIFAR10_CLASSES.map(c => (
                <div key={c.id} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 1 }}>
                  <span style={{ fontSize: 13 }}>{c.emoji}</span>
                  <span style={{ fontSize: 10, color: "#94a3b8", lineHeight: 1 }}>{c.name.slice(0, 4)}</span>
                </div>
              ))}
            </div>

            {/* Rows */}
            {confusionMatrix.map((row, ri) => (
              <motion.div
                key={ri}
                initial={{ opacity: 0, x: -7 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.26, delay: ri * 0.025 }}
                style={{ display: "flex", alignItems: "center", marginBottom: 2, position: "relative", zIndex: 0 }}
              >
                {/* Row label */}
                <div style={{ width: 60, flexShrink: 0, display: "flex", alignItems: "center", gap: 3, paddingRight: 4 }}>
                  <span style={{ fontSize: 13 }}>{CIFAR10_CLASSES[ri].emoji}</span>
                  <span style={{ fontSize: 10, color: "#94a3b8" }}>{CIFAR10_CLASSES[ri].name.slice(0, 4)}</span>
                </div>

                {/* Cells */}
                {row.map((val, ci) => {
                  const isMain = ri === ci;
                  const isHov  = hov?.r === ri && hov?.c === ci;
                  return (
                    <div
                      key={ci}
                      onMouseEnter={() => setHov({ r: ri, c: ci })}
                      // No onMouseLeave here — section handles it to avoid flicker
                      style={{
                        flex: 1,
                        aspectRatio: "1/1",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        background: cellBg(val, rowMax[ri], isMain),
                        borderRadius: 6,
                        margin: "1px",
                        fontSize: "0.76rem",
                        fontWeight: 700,
                        color: isMain && val > 550 ? "white" : "#111827",
                        cursor: "default",
                        position: "relative",
                        zIndex: isHov ? 30 : 1,
                        isolation: "isolate",
                        transform: isHov ? "scale(1.30) translateZ(0)" : "scale(1) translateZ(0)",
                        boxShadow: isHov
                          ? "0 6px 22px rgba(124,58,237,0.50), 0 2px 8px rgba(0,0,0,0.22)"
                          : "none",
                        transition: "transform 0.09s cubic-bezier(0.22,1,0.36,1), box-shadow 0.09s ease",
                        willChange: "transform",
                      }}
                    >
                      {val > 0 ? val : ""}
                    </div>
                  );
                })}
              </motion.div>
            ))}

            {/* Legend */}
            <div style={{ display: "flex", gap: 18, marginTop: 15, flexWrap: "wrap", justifyContent: "center" }}>
              {[
                ["rgba(124,58,237,0.68)", "Correct (diagonal)"],
                ["rgba(220,38,38,0.40)",  "High misclassification"],
                ["rgba(124,58,237,0.07)", "Rare errors"],
              ].map(([bg, lbl]) => (
                <span key={lbl} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12, color: "#64748b" }}>
                  <span style={{ width: 12, height: 12, borderRadius: 3, background: bg, display: "inline-block" }}/>
                  {lbl}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
