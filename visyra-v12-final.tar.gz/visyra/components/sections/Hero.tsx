"use client";
import { useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import Image from "next/image";

/**
 * Hero section — parallax via native rAF (zero Framer Motion scroll overhead).
 *
 * Why this is faster than useScroll + useTransform:
 * ──────────────────────────────────────────────────
 * Framer's useScroll creates a MotionValue subscription that fires on every
 * scroll event, queues a React reconciliation, and then applies transforms.
 * That pipeline has 2–3 intermediate hops (MotionValue → useTransform →
 * style setter). On iOS with momentum scrolling, this introduces visible lag.
 *
 * The native rAF approach does: scroll → arithmetic → element.style.transform.
 * One hop. No React. Runs entirely on the compositor thread.
 *
 * Performance properties:
 * • IntersectionObserver gating — rAF is a no-op when hero is off-screen
 * • Early-exit when scrollY unchanged — skips ~50% of frames during fast scroll
 * • All transforms use translate3d / scale3d — compositor only, no layout
 * • willChange set at mount — GPU layer promoted before first scroll event
 * • Staircase uses CSS aurora animation — zero JS cost
 */

// ── Staircase backdrop ────────────────────────────────────────────────────────
function Staircase() {
  const steps = [
    { w: "13%",  h: 240, top: "8%",  op: 0.68 },
    { w: "23%",  h: 208, top: "12%", op: 0.54 },
    { w: "35%",  h: 176, top: "16%", op: 0.44 },
    { w: "50%",  h: 144, top: "20%", op: 0.33 },
    { w: "67%",  h: 114, top: "24%", op: 0.22 },
    { w: "85%",  h: 86,  top: "28%", op: 0.12 },
    { w: "103%", h: 60,  top: "32%", op: 0.06 },
  ];
  return (
    <div style={{
      position: "absolute", inset: 0,
      display: "flex", alignItems: "center", justifyContent: "center",
      pointerEvents: "none", overflow: "hidden",
    }}>
      {steps.map((s, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: s.op, y: 0 }}
          transition={{ duration: 0.9, delay: 0.05 + i * 0.07, ease: [0.22, 1, 0.36, 1] }}
          style={{
            position: "absolute", width: s.w, height: s.h, top: s.top,
            background: `linear-gradient(160deg,
              rgba(196,181,253,${(0.64 - i * 0.07).toFixed(3)}) 0%,
              rgba(167,139,250,${(0.38 - i * 0.04).toFixed(3)}) 55%,
              rgba(124,58,237,${(0.13 - i * 0.015).toFixed(3)}) 100%)`,
            borderRadius: 26,
            // CSS animation only — no JS scroll handler
            animation: `aurora-a ${22 + i * 5}s cubic-bezier(0.45,0.05,0.55,0.95) infinite`,
            animationDelay: `${-i * 3.5}s`,
            willChange: "transform",
          }}
        />
      ))}
    </div>
  );
}

// ── Hero ──────────────────────────────────────────────────────────────────────
export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);

  // DOM refs for the three parallax layers — written directly, no React state
  const stairWrapRef   = useRef<HTMLDivElement>(null);  // slowest
  const contentWrapRef = useRef<HTMLDivElement>(null);  // fastest
  const imageWrapRef   = useRef<HTMLDivElement>(null);  // intermediate

  useEffect(() => {
    const section     = sectionRef.current;
    const stairWrap   = stairWrapRef.current;
    const contentWrap = contentWrapRef.current;
    const imageWrap   = imageWrapRef.current;
    if (!section || !stairWrap || !contentWrap || !imageWrap) return;

    // Respect reduced-motion
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const isMobile = window.matchMedia("(max-width: 768px)").matches;

    // Parallax speeds — lower = slower (more depth)
    // Mobile values are halved: iOS momentum scroll is 2× sensitive to jitter
    const SPEED_STAIR   = isMobile ? 0.025 : 0.055;  // staircase drifts slowly
    const SPEED_CONTENT = isMobile ? 0.06  : 0.12;   // content moves with scroll
    const SPEED_IMAGE   = isMobile ? 0.02  : 0.045;  // image moves counter to content

    // Fade: content opacity drops as scroll progress increases past 50%
    const FADE_START = 0.35;  // as fraction of section height
    const FADE_END   = 0.65;

    let raf    = 0;
    let lastSY = -1;
    let sectionH = section.offsetHeight;

    // Cache section height on resize (cheap)
    const ro = new ResizeObserver(() => { sectionH = section.offsetHeight; });
    ro.observe(section);

    // IntersectionObserver — pause rAF when hero is fully off-screen
    let visible = true;
    const io = new IntersectionObserver(
      ([e]) => { visible = e.isIntersecting; },
      { rootMargin: "10% 0px 10% 0px" }
    );
    io.observe(section);

    const tick = () => {
      raf = requestAnimationFrame(tick);
      if (!visible) return;

      const sy = window.scrollY;
      if (Math.abs(sy - lastSY) < 0.35) return;  // skip static frames
      lastSY = sy;

      // progress: 0 at top of hero, 1 when hero top reaches viewport top
      const sectionTop = section.getBoundingClientRect().top + sy;
      const rawProg    = sy <= sectionTop ? 0 : (sy - sectionTop) / sectionH;
      const prog       = Math.max(0, Math.min(1, rawProg));

      // Staircase — slow upward drift
      const stairOff = prog * sectionH * SPEED_STAIR;
      stairWrap.style.transform = `translate3d(0,${stairOff.toFixed(2)}px,0)`;

      // Content — faster upward lift + fade
      const contentOff = prog * sectionH * SPEED_CONTENT;
      const fadeT      = Math.max(0, Math.min(1, (prog - FADE_START) / (FADE_END - FADE_START)));
      const opacity    = (1 - fadeT).toFixed(3);
      contentWrap.style.transform = `translate3d(0,${contentOff.toFixed(2)}px,0)`;
      contentWrap.style.opacity   = opacity;

      // Image — moves slightly opposite to content for depth separation
      const imageOff   = -(prog * sectionH * SPEED_IMAGE);
      const imageScale = (1 - prog * 0.12).toFixed(4);  // subtle shrink
      imageWrap.style.transform = `translate3d(0,${imageOff.toFixed(2)}px,0) scale3d(${imageScale},${imageScale},1)`;
    };

    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      io.disconnect();
      ro.disconnect();
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      style={{ position: "relative", minHeight: "100svh", overflow: "hidden" }}
    >
      {/* Staircase layer — slowest */}
      <div
        ref={stairWrapRef}
        style={{
          position: "absolute", inset: 0, zIndex: 0,
          willChange: "transform",
          transform: "translate3d(0,0,0)",
        }}
      >
        <Staircase />
      </div>

      {/* Content layer — fastest + fades */}
      <div
        ref={contentWrapRef}
        style={{ willChange: "transform, opacity", transform: "translate3d(0,0,0)" }}
      >
        {/* Entrance fade-in via Framer (one-time only, no ongoing scroll) */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div style={{
            position: "relative", zIndex: 10,
            display: "flex", flexDirection: "column", alignItems: "center",
            textAlign: "center",
            padding: "clamp(60px,9vh,88px) 20px 44px",
          }}>

            {/* Eyebrow chip */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
              style={{
                display: "inline-flex", alignItems: "center", gap: 7,
                background: "rgba(237,233,254,0.92)",
                border: "1px solid rgba(124,58,237,0.2)",
                borderRadius: 20, padding: "6px 16px",
                marginBottom: "clamp(30px,5vh,46px)",
                fontSize: 12, fontWeight: 700, color: "#6d28d9",
                letterSpacing: "0.07em", textTransform: "uppercase",
                WebkitBackdropFilter: "blur(8px)", backdropFilter: "blur(8px)",
              }}
            >
              <span className="anim-pulse-dot" style={{
                width: 7, height: 7, borderRadius: "50%", background: "#7c3aed", flexShrink: 0,
              }}/>
              ICT 120 — Intelligent Systems
            </motion.div>

            {/* Hero image — intermediate depth layer */}
            <motion.div
              initial={{ opacity: 0, scale: 0.82 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.9, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
              style={{ marginBottom: "clamp(30px,5vh,46px)", position: "relative" }}
            >
              {/* This inner div receives the scroll transform */}
              <div
                ref={imageWrapRef}
                style={{
                  willChange: "transform",
                  transform: "translate3d(0,0,0) scale3d(1,1,1)",
                  position: "relative",
                }}
              >
                {/* Ambient glow */}
                <div style={{
                  position: "absolute", top: "50%", left: "50%",
                  transform: "translate(-50%,-50%)",
                  width: "150%", height: "140%", borderRadius: "50%",
                  background: "radial-gradient(ellipse,rgba(124,58,237,0.30) 0%,rgba(192,38,211,0.14) 36%,transparent 68%)",
                  filter: "blur(28px)", pointerEvents: "none",
                }}/>

                {/* Orbit ring CW */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 24, repeat: Infinity, ease: "linear" }}
                  style={{
                    position: "absolute", inset: -20, borderRadius: "50%",
                    border: "1.5px solid transparent",
                    borderTopColor: "rgba(124,58,237,0.48)",
                    borderRightColor: "rgba(196,181,253,0.18)",
                    willChange: "transform",
                  }}
                />
                {/* Orbit ring CCW */}
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{ duration: 36, repeat: Infinity, ease: "linear" }}
                  style={{
                    position: "absolute", inset: -33, borderRadius: "50%",
                    border: "1px dashed rgba(192,38,211,0.16)",
                    willChange: "transform",
                  }}
                />

                {/* Visyra image — CSS float animation */}
                <div className="anim-float" style={{ position: "relative", willChange: "transform" }}>
                  <Image
                    src="/visyra.png"
                    alt="Visyra"
                    width={272}
                    height={181}
                    style={{
                      objectFit: "contain",
                      filter: "drop-shadow(0 28px 52px rgba(91,33,182,0.58)) drop-shadow(0 8px 18px rgba(192,38,211,0.26))",
                    }}
                    priority
                  />
                </div>
              </div>
            </motion.div>

            {/* Two-column flanking text */}
            <div
              style={{
                display: "grid", gridTemplateColumns: "1fr 1px 1fr", gap: "0 36px",
                alignItems: "start", width: "100%", maxWidth: 820,
                marginBottom: 38, textAlign: "left",
              }}
              className="max-sm:flex max-sm:flex-col max-sm:text-center max-sm:items-center"
            >
              <motion.div
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.38, ease: [0.22, 1, 0.36, 1] }}
              >
                <h1 style={{
                  fontSize: "clamp(2.1rem,4vw,3rem)",
                  fontWeight: 800, lineHeight: 1.07,
                  letterSpacing: "-0.035em", color: "#09090e",
                  fontFamily: "-apple-system,'SF Pro Display','Inter',system-ui,sans-serif",
                }}>
                  Image Classification<br />with CIFAR-10
                </h1>
                <p style={{ marginTop: 14, fontSize: 15, lineHeight: 1.7, color: "#64748b", maxWidth: 270 }}>
                  A project for{" "}
                  <strong style={{ color: "#09090e", fontWeight: 600 }}>ICT 120 — Intelligent Systems</strong>
                  , a Convolutional Neural Network trained on 60,000 images across 10 object classes.
                </p>
              </motion.div>

              <div className="hide-mobile" style={{ background: "rgba(0,0,0,0.07)", alignSelf: "stretch", minHeight: 90 }}/>

              <motion.div
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.44, ease: [0.22, 1, 0.36, 1] }}
                style={{ display: "flex", flexDirection: "column", gap: 16 }}
                className="max-sm:items-center max-sm:mt-6"
              >
                {[
                  { label: "Architecture", val: "Custom CNN · 6 Conv2D layers" },
                  { label: "Dataset",      val: "CIFAR-10 · 60,000 images"    },
                  { label: "Parameters",   val: "552K total · all trainable"   },
                  { label: "Inference",    val: "In-browser · TensorFlow.js"  },
                ].map(({ label, val }) => (
                  <div key={label}>
                    <div style={{
                      fontSize: 11, fontWeight: 700, color: "#94a3b8",
                      textTransform: "uppercase", letterSpacing: "0.1em",
                    }}>{label}</div>
                    <div style={{ fontSize: 14.5, fontWeight: 600, color: "#09090e", marginTop: 2 }}>{val}</div>
                  </div>
                ))}
              </motion.div>
            </div>

            {/* CTA */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.56, ease: [0.22, 1, 0.36, 1] }}
              style={{ display: "flex", gap: 14, alignItems: "center", flexWrap: "wrap", justifyContent: "center" }}
            >
              <a
                href="#predict"
                style={{
                  display: "inline-flex", alignItems: "center", gap: 8,
                  background: "#09090e", color: "white",
                  fontSize: 14, fontWeight: 700, letterSpacing: "-0.01em",
                  padding: "13px 26px", borderRadius: 24, textDecoration: "none",
                  boxShadow: "0 4px 20px rgba(0,0,0,0.20)",
                  transition: "transform 0.12s cubic-bezier(0.22,1,0.36,1), box-shadow 0.12s ease",
                }}
                onMouseEnter={e => {
                  const el = e.currentTarget as HTMLElement;
                  el.style.transform  = "translateY(-2px)";
                  el.style.boxShadow  = "0 8px 28px rgba(0,0,0,0.26)";
                }}
                onMouseLeave={e => {
                  const el = e.currentTarget as HTMLElement;
                  el.style.transform  = "translateY(0)";
                  el.style.boxShadow  = "0 4px 20px rgba(0,0,0,0.20)";
                }}
              >
                Try a Prediction <ArrowRight size={14}/>
              </a>
              <a
                href="#metrics"
                style={{
                  display: "inline-flex", alignItems: "center",
                  color: "#64748b", fontSize: 14, fontWeight: 500,
                  textDecoration: "none", transition: "color 0.1s ease",
                }}
                onMouseEnter={e => (e.currentTarget as HTMLElement).style.color = "#09090e"}
                onMouseLeave={e => (e.currentTarget as HTMLElement).style.color = "#64748b"}
              >
                View results →
              </a>
            </motion.div>

            {/* Scroll cue */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.0 }}
              style={{
                display: "flex", flexDirection: "column", alignItems: "center",
                gap: 5, marginTop: "clamp(28px,4vh,42px)",
              }}
            >
              <span style={{ fontSize: 10, color: "#94a3b8", letterSpacing: "0.2em", textTransform: "uppercase" }}>
                Scroll
              </span>
              <div style={{
                width: 1, height: 26,
                background: "linear-gradient(to bottom,rgba(124,58,237,0.5),transparent)",
              }}/>
            </motion.div>

          </div>
        </motion.div>
      </div>
    </section>
  );
}
