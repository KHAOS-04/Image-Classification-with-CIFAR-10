"use client";
import { useState, useRef, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload, RefreshCcw, CheckCircle2, Image as ImageIcon,
  ChevronDown, ChevronUp, Brain, AlertTriangle, Wifi,
} from "lucide-react";
import {
  RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer,
} from "recharts";
import { useModel, CLASS_NAMES, CLASS_EMOJIS } from "@/lib/useModel";

// ── Sample palette ────────────────────────────────────────────────────────────
const SAMPLES = [
  { label:"Airplane",   emoji:"✈️",  classIdx:0, r:135, g:170, b:210 },
  { label:"Automobile", emoji:"🚗",  classIdx:1, r:180, g:50,  b:50  },
  { label:"Bird",       emoji:"🐦",  classIdx:2, r:90,  g:130, b:80  },
  { label:"Cat",        emoji:"🐱",  classIdx:3, r:190, g:155, b:120 },
  { label:"Deer",       emoji:"🦌",  classIdx:4, r:155, g:110, b:60  },
  { label:"Dog",        emoji:"🐶",  classIdx:5, r:200, g:165, b:110 },
];

// ── Inference message sequences ───────────────────────────────────────────────
const INFER_MSGS = [
  "Resizing to 32×32…",
  "Normalising pixels…",
  "Running Conv2D blocks…",
  "Dense layer + softmax…",
  "Extracting scores…",
];
const MODEL_MSGS = [
  "Fetching CNN weights…",
  "Initialising TensorFlow.js…",
  "Compiling compute graph…",
  "Running warm-up pass…",
];

// ── Draw a colour canvas representing a CIFAR class ───────────────────────────
function makeSampleCanvas(r: number, g: number, b: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = 32; c.height = 32;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = `rgb(${r},${g},${b})`;
  ctx.fillRect(0, 0, 32, 32);
  for (let i = 0; i < 180; i++) {
    ctx.fillStyle = `rgba(
      ${Math.min(255, r + (Math.random() - 0.5) * 60) | 0},
      ${Math.min(255, g + (Math.random() - 0.5) * 60) | 0},
      ${Math.min(255, b + (Math.random() - 0.5) * 60) | 0},
      0.55)`;
    ctx.fillRect(Math.random()*28, Math.random()*28, Math.random()*6+2, Math.random()*6+2);
  }
  return c;
}

// ── Animated confidence bar ───────────────────────────────────────────────────
function Bar({ pct, active = true, delay = 0 }: { pct: number; active?: boolean; delay?: number }) {
  return (
    <motion.div
      initial={{ width: 0 }}
      animate={{ width: `${Math.min(pct, 100)}%` }}
      transition={{ duration: 0.65, delay: delay / 1000, ease: [0.22, 1, 0.36, 1] }}
      style={{
        height: "100%", borderRadius: 99,
        background: active
          ? "linear-gradient(90deg,#6d28d9,#a855f7)"
          : "rgba(124,58,237,0.22)",
      }}
    />
  );
}

// ── Animated count-up number ──────────────────────────────────────────────────
function CountUp({ to, suffix = "" }: { to: number; suffix?: string }) {
  const [v, setV] = useState(0);
  const ran = useRef(false);
  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    let c = 0;
    const iv = setInterval(() => {
      c += to / 36;
      if (c >= to) { setV(to); clearInterval(iv); } else setV(c);
    }, 700 / 36);
    return () => clearInterval(iv);
  }, [to]);
  return <>{v.toFixed(1)}{suffix}</>;
}

// ─────────────────────────────────────────────────────────────────────────────
export default function UploadPredict() {
  const { status, loadPct, load, predict } = useModel();

  const [drag,    setDrag]    = useState(false);
  const [glow,    setGlow]    = useState(false);
  const [preview, setPrev]    = useState<string | null>(null);
  const [running, setRunning] = useState(false);
  const [msgIdx,  setMsgIdx]  = useState(0);
  const [result,  setResult]  = useState<Awaited<ReturnType<typeof predict>>>(null);
  const [showAll, setAll]     = useState(false);

  // The 32×32 canvas ready for inference — set by upload OR by sample selection
  const srcCanvas = useRef<HTMLCanvasElement | null>(null);
  const inputRef  = useRef<HTMLInputElement>(null);
  const msgTimer  = useRef<ReturnType<typeof setInterval> | null>(null);

  // Pre-warm model on mount
  useEffect(() => { load(); }, [load]);
  useEffect(() => () => { if (msgTimer.current) clearInterval(msgTimer.current); }, []);

  // ── Message cycling ────────────────────────────────────────────────────────
  const startMsgs = useCallback((msgs: string[]) => {
    let i = 0;
    if (msgTimer.current) clearInterval(msgTimer.current);
    msgTimer.current = setInterval(() => { i = (i + 1) % msgs.length; setMsgIdx(i); }, 480);
  }, []);
  const stopMsgs = useCallback(() => {
    if (msgTimer.current) { clearInterval(msgTimer.current); msgTimer.current = null; }
  }, []);

  // ── Core inference ─────────────────────────────────────────────────────────
  const runInference = useCallback(async (canvas: HTMLCanvasElement) => {
    setRunning(true); setResult(null); setAll(false);
    startMsgs(INFER_MSGS);
    try {
      const res = await predict(canvas);
      setResult(res);
    } catch (err) {
      console.error("[Visyra] Inference error:", err);
    } finally {
      stopMsgs();
      setRunning(false);
    }
  }, [predict, startMsgs, stopMsgs]);

  // ── Upload handler — preprocess + infer in one shot ────────────────────────
  // The user drops/picks a file. We:
  //   1. Draw to a 32×32 canvas immediately (no separate step)
  //   2. Update the preview
  //   3. Auto-trigger inference — no extra button click needed
  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) return;
    const url = URL.createObjectURL(file);
    const img  = new Image();
    img.onload = () => {
      // 32×32 canvas — used for inference
      const c = document.createElement("canvas");
      c.width = 32; c.height = 32;
      c.getContext("2d")!.drawImage(img, 0, 0, 32, 32);
      srcCanvas.current = c;

      // 128×128 canvas — used for the preview thumbnail
      const disp = document.createElement("canvas");
      disp.width = 128; disp.height = 128;
      disp.getContext("2d")!.drawImage(img, 0, 0, 128, 128);
      setPrev(disp.toDataURL());
      URL.revokeObjectURL(url);

      // Auto-run inference — no button click required
      if (status === "ready") {
        runInference(c);
      } else {
        // Model still loading — store canvas; inference will trigger once ready
        // (user can see the preview and click the button when it appears)
      }
    };
    img.src = url;
  }, [status, runInference]);

  // ── Sample handler — select + infer in one shot ────────────────────────────
  const handleSample = useCallback((s: typeof SAMPLES[number]) => {
    const canvas = makeSampleCanvas(s.r, s.g, s.b);
    srcCanvas.current = canvas;
    // Preview
    const disp = document.createElement("canvas");
    disp.width = 128; disp.height = 128;
    disp.getContext("2d")!.drawImage(canvas, 0, 0, 128, 128);
    setPrev(disp.toDataURL());
    // Auto-run inference
    runInference(canvas);
  }, [runInference]);

  // ── Re-run button — appears when upload lands while model was loading ──────
  // If model wasn't ready when file was dropped, this lets the user trigger
  // inference once the model finishes loading.
  const canRerun = preview && !running && result === null && status === "ready" && srcCanvas.current;

  const isLoading  = running || status === "loading";
  const activeMsg  = running
    ? INFER_MSGS[msgIdx % INFER_MSGS.length]
    : MODEL_MSGS[Math.min(Math.floor(loadPct / 26), MODEL_MSGS.length - 1)];

  const radarData = result
    ? CLASS_NAMES.map((n, i) => ({ s: n, v: result!.allScores[i] }))
    : [];

  const F: React.CSSProperties = { fontFamily: "-apple-system,'SF Pro Text','Inter',sans-serif" };

  return (
    <section id="predict" style={{ padding: "52px 20px" }}>
      <div style={{ maxWidth: 1040, margin: "0 auto" }}>

        {/* ── Header ─────────────────────────────────────────────────────── */}
        <motion.div initial={{ opacity:0, y:14 }} whileInView={{ opacity:1, y:0 }}
          viewport={{ once:true }} transition={{ duration:0.5 }}
          style={{ marginBottom:28 }}>
          <p style={{ fontSize:12, fontWeight:700, color:"#7c3aed",
            textTransform:"uppercase", letterSpacing:"0.15em", marginBottom:9, ...F }}>
            Neural Inference
          </p>
          <h2 style={{ fontSize:"clamp(1.9rem,3.5vw,2.65rem)", fontWeight:800,
            letterSpacing:"-0.03em", color:"#09090e", lineHeight:1.08, ...F }}>
            Classify an Image
          </h2>
          <p style={{ marginTop:9, fontSize:15, color:"#64748b", lineHeight:1.68, ...F }}>
            Drop an image or pick a sample — inference runs automatically.
          </p>

          {/* Model status chip */}
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ delay:0.3 }}
            style={{ marginTop:12, display:"inline-flex", alignItems:"center", gap:6,
              background: status==="ready" ? "rgba(16,185,129,0.08)"
                        : status==="error" ? "rgba(239,68,68,0.08)"
                        : "rgba(124,58,237,0.07)",
              border: `1px solid ${status==="ready" ? "rgba(16,185,129,0.2)"
                        : status==="error" ? "rgba(239,68,68,0.2)"
                        : "rgba(124,58,237,0.15)"}`,
              borderRadius:20, padding:"4px 12px" }}>
            <div style={{ width:6, height:6, borderRadius:"50%", flexShrink:0,
              background: status==="ready" ? "#10b981" : status==="error" ? "#ef4444" : "#7c3aed",
              ...(status==="loading" ? { animation:"pulse-dot 1.5s ease-out infinite" } : {}) }}/>
            <span style={{ fontSize:11, fontWeight:600, ...F,
              color: status==="ready" ? "#059669" : status==="error" ? "#dc2626" : "#6d28d9" }}>
              {status==="ready"    ? "CNN ready · 552K parameters"
               :status==="loading" ? `Loading model… ${loadPct}%`
               :status==="error"   ? "Model failed to load · refresh to retry"
               : "Initialising…"}
            </span>
          </motion.div>
        </motion.div>

        {/* ── Main bento grid ────────────────────────────────────────────── */}
        <div style={{ display:"grid", gridTemplateColumns:"minmax(0,1fr) minmax(0,1fr)", gap:12 }}
          className="max-md:block">

          {/* ── LEFT: dropzone + samples ──────────────────────────────────── */}
          <motion.div initial={{ opacity:0, x:-14 }} whileInView={{ opacity:1, x:0 }}
            viewport={{ once:true }} transition={{ duration:0.48 }}
            style={{ display:"flex", flexDirection:"column", gap:10 }}
            className="max-md:mb-3">

            {/* Dropzone */}
            <div
              style={{
                background: "#0c0c14",
                border: `1.5px dashed ${drag ? "rgba(124,58,237,0.85)" : glow ? "rgba(124,58,237,0.48)" : "rgba(255,255,255,0.10)"}`,
                borderRadius: 22, padding: "36px 28px", minHeight: 188,
                display: "flex", flexDirection: "column",
                alignItems: "center", justifyContent: "center",
                cursor: "pointer", position: "relative", overflow: "hidden",
                transition: "border-color 0.16s ease, box-shadow 0.20s ease",
                boxShadow: (glow || drag)
                  ? "0 0 0 1px rgba(124,58,237,0.22), 0 0 36px rgba(124,58,237,0.24), inset 0 0 40px rgba(124,58,237,0.09)"
                  : "none",
              }}
              onMouseEnter={() => setGlow(true)}
              onMouseLeave={() => setGlow(false)}
              onDragOver={e => { e.preventDefault(); setDrag(true); setGlow(true); }}
              onDragLeave={() => { setDrag(false); setGlow(false); }}
              onDrop={e => {
                e.preventDefault(); setDrag(false); setGlow(false);
                const f = e.dataTransfer.files[0]; if (f) handleFile(f);
              }}
              onClick={() => inputRef.current?.click()}
            >
              {/* Inner glow orb */}
              <div style={{
                position:"absolute", top:"-25%", left:"12%", width:"76%", height:"130%",
                borderRadius:"50%", pointerEvents:"none", filter:"blur(12px)",
                background: (glow||drag)
                  ? "radial-gradient(ellipse,rgba(124,58,237,0.30) 0%,transparent 70%)"
                  : "radial-gradient(ellipse,rgba(124,58,237,0.12) 0%,transparent 70%)",
                transition: "background 0.20s ease",
              }}/>

              <input ref={inputRef} type="file" accept="image/*" style={{ display:"none" }}
                onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }}/>

              {preview ? (
                <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:10, position:"relative" }}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={preview} alt="preview"
                    style={{ width:92, height:92, objectFit:"cover", borderRadius:14,
                      boxShadow:"0 8px 28px rgba(0,0,0,0.55)", imageRendering:"pixelated" }}/>
                  <span style={{ fontSize:12, color:"rgba(255,255,255,0.35)", ...F }}>
                    {running ? "Processing…" : "Click to change image"}
                  </span>
                </div>
              ) : (
                <div style={{ textAlign:"center", position:"relative" }}>
                  <motion.div
                    animate={{ scale: drag ? 1.14 : glow ? 1.06 : 1 }}
                    transition={{ duration:0.14 }}
                    style={{
                      width:52, height:52, borderRadius:14, margin:"0 auto 14px",
                      display:"flex", alignItems:"center", justifyContent:"center",
                      background: (glow||drag) ? "rgba(124,58,237,0.30)" : "rgba(124,58,237,0.16)",
                      border: `1px solid ${(glow||drag) ? "rgba(124,58,237,0.55)" : "rgba(124,58,237,0.28)"}`,
                      boxShadow: (glow||drag) ? "0 0 22px rgba(124,58,237,0.32)" : "none",
                      transition: "background 0.16s, border-color 0.16s, box-shadow 0.16s",
                    }}>
                    <Upload size={21} color={(glow||drag) ? "rgba(216,180,254,1)" : "rgba(196,181,253,0.85)"}/>
                  </motion.div>
                  <p style={{ fontSize:15, fontWeight:600, color:"rgba(255,255,255,0.86)", marginBottom:4, ...F }}>
                    Drop your image here
                  </p>
                  <p style={{ fontSize:13, color:"rgba(255,255,255,0.30)", ...F }}>
                    or click to browse · inference runs automatically
                  </p>
                </div>
              )}
            </div>

            {/* Fallback run button — only shows if model was loading when image was dropped */}
            <AnimatePresence>
              {canRerun && (
                <motion.button
                  initial={{ opacity:0, y:6 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:3 }}
                  transition={{ duration:0.16 }}
                  whileHover={{ scale:1.015 }} whileTap={{ scale:0.97 }}
                  onClick={() => srcCanvas.current && runInference(srcCanvas.current)}
                  style={{ border:"none", cursor:"pointer", borderRadius:16, padding:"13px",
                    background:"linear-gradient(135deg,#7c3aed,#5b21b6)",
                    color:"white", fontSize:13, fontWeight:700, ...F,
                    boxShadow:"0 0 26px rgba(124,58,237,0.38)",
                    display:"flex", alignItems:"center", justifyContent:"center", gap:7 }}>
                  <Brain size={14}/> Run Inference
                </motion.button>
              )}
            </AnimatePresence>

            {/* Samples */}
            <div>
              <p style={{ fontSize:11, fontWeight:700, color:"#94a3b8",
                textTransform:"uppercase", letterSpacing:"0.14em", marginBottom:9, ...F }}>
                Try a sample
              </p>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:7 }}>
                {SAMPLES.map(s => (
                  <motion.button key={s.classIdx}
                    whileHover={{ y:-3 }} whileTap={{ scale:0.95 }} transition={{ duration:0.1 }}
                    onClick={() => handleSample(s)}
                    disabled={status !== "ready" || running}
                    style={{ background:"#ffffff", border:"1px solid rgba(0,0,0,0.07)",
                      borderRadius:13, padding:"9px 4px",
                      display:"flex", flexDirection:"column", alignItems:"center", gap:3,
                      cursor: status==="ready" && !running ? "pointer" : "not-allowed",
                      opacity: status==="ready" && !running ? 1 : 0.45,
                      boxShadow:"0 1px 4px rgba(0,0,0,0.05)", ...F }}>
                    <span style={{ fontSize:17 }}>{s.emoji}</span>
                    <span style={{ fontSize:11, fontWeight:600, color:"#374151" }}>{s.label}</span>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>

          {/* ── RIGHT: result panel ───────────────────────────────────────── */}
          <motion.div initial={{ opacity:0, x:14 }} whileInView={{ opacity:1, x:0 }}
            viewport={{ once:true }} transition={{ duration:0.48, delay:0.07 }}>
            <AnimatePresence mode="wait">

              {/* Loading / running */}
              {isLoading && (
                <motion.div key="loading"
                  initial={{ opacity:0, scale:0.97 }} animate={{ opacity:1, scale:1 }}
                  exit={{ opacity:0, scale:0.97 }} transition={{ duration:0.16 }}
                  style={{ background:"#ffffff", border:"1px solid rgba(0,0,0,0.07)",
                    borderRadius:22, padding:36, minHeight:300,
                    display:"flex", flexDirection:"column", alignItems:"center",
                    justifyContent:"center", gap:18, ...F }}>
                  <div style={{ position:"relative", width:52, height:52,
                    display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <div className="anim-spin-cw" style={{ position:"absolute", inset:0,
                      borderRadius:"50%", border:"2px solid transparent", borderTop:"2px solid #7c3aed" }}/>
                    <div className="anim-spin-ccw" style={{ position:"absolute", inset:7,
                      borderRadius:"50%", border:"2px solid transparent", borderBottom:"2px solid #c4b5fd" }}/>
                    <Brain size={14} color="#7c3aed"/>
                  </div>
                  <div style={{ textAlign:"center" }}>
                    <p style={{ fontSize:14, fontWeight:600, color:"#374151", marginBottom:3 }}>
                      {activeMsg}
                    </p>
                    <p style={{ fontSize:12, color:"#94a3b8" }}>
                      {status==="loading" ? `Downloading CNN weights… ${loadPct}%` : "In-browser TensorFlow.js"}
                    </p>
                  </div>
                  {status==="loading" && (
                    <div style={{ width:140, height:3, background:"#f1f5f9", borderRadius:99, overflow:"hidden" }}>
                      <motion.div animate={{ width:`${loadPct}%` }} transition={{ duration:0.25 }}
                        style={{ height:"100%", borderRadius:99,
                          background:"linear-gradient(90deg,#7c3aed,#a855f7)" }}/>
                    </div>
                  )}
                  {running && (
                    <div style={{ width:100, height:3, borderRadius:99, overflow:"hidden" }}>
                      <div className="shimmer-bar" style={{ width:"100%", height:"100%" }}/>
                    </div>
                  )}
                </motion.div>
              )}

              {/* Error */}
              {status==="error" && !isLoading && (
                <motion.div key="error" initial={{ opacity:0 }} animate={{ opacity:1 }}
                  style={{ background:"rgba(239,68,68,0.04)", border:"1px solid rgba(239,68,68,0.14)",
                    borderRadius:22, padding:40, minHeight:300,
                    display:"flex", flexDirection:"column", alignItems:"center",
                    justifyContent:"center", gap:12, textAlign:"center", ...F }}>
                  <div style={{ width:48, height:48, borderRadius:13, background:"rgba(239,68,68,0.08)",
                    display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <AlertTriangle size={22} color="#ef4444"/>
                  </div>
                  <p style={{ fontSize:15, fontWeight:700, color:"#dc2626" }}>Model failed to load</p>
                  <p style={{ fontSize:13, color:"#94a3b8", maxWidth:240, lineHeight:1.6 }}>
                    Check your network. The CNN weights (~2.2 MB) need to download once.
                  </p>
                  <motion.button whileHover={{ scale:1.02 }} whileTap={{ scale:0.97 }}
                    onClick={() => load()}
                    style={{ display:"inline-flex", alignItems:"center", gap:6,
                      background:"#09090e", color:"white", border:"none",
                      fontSize:13, fontWeight:600, borderRadius:12, padding:"9px 18px",
                      cursor:"pointer", ...F }}>
                    <Wifi size={13}/> Retry
                  </motion.button>
                </motion.div>
              )}

              {/* Result */}
              {result && !isLoading && (
                <motion.div key="result"
                  initial={{ opacity:0, y:12 }} animate={{ opacity:1, y:0 }}
                  exit={{ opacity:0 }} transition={{ duration:0.24 }}
                  style={{ background:"#ffffff", border:"1px solid rgba(0,0,0,0.07)",
                    borderRadius:22, padding:22,
                    display:"flex", flexDirection:"column", gap:14, ...F }}>

                  {/* Class + confidence */}
                  <div style={{ display:"flex", alignItems:"center", gap:13 }}>
                    <div style={{ width:54, height:54, borderRadius:15, flexShrink:0,
                      background:"linear-gradient(135deg,rgba(124,58,237,0.09),rgba(91,33,182,0.04))",
                      display:"flex", alignItems:"center", justifyContent:"center",
                      fontSize:"1.7rem", boxShadow:"0 0 16px rgba(124,58,237,0.14)" }}>
                      {result.emoji}
                    </div>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:5, marginBottom:2 }}>
                        <CheckCircle2 size={12} color="#10b981"/>
                        <span style={{ fontSize:12, color:"#10b981", fontWeight:600 }}>
                          Classified · {result.inferenceMs} ms
                        </span>
                      </div>
                      <p style={{ fontSize:23, fontWeight:800, color:"#09090e",
                        letterSpacing:"-0.025em", lineHeight:1 }}>
                        {result.className}
                      </p>
                      <p style={{ fontSize:12, color:"#94a3b8", marginTop:2 }}>
                        CIFAR-10 class {result.classIdx} · Custom CNN
                      </p>
                    </div>
                    <div style={{ textAlign:"right", flexShrink:0 }}>
                      <p style={{ fontSize:28, fontWeight:800, color:"#7c3aed",
                        lineHeight:1, letterSpacing:"-0.02em" }}>
                        <CountUp to={result.confidence} suffix="%"/>
                      </p>
                      <p style={{ fontSize:11, color:"#94a3b8", marginTop:2 }}>confidence</p>
                    </div>
                  </div>

                  {/* Confidence bar */}
                  <div style={{ height:4, background:"#f1f5f9", borderRadius:99, overflow:"hidden" }}>
                    <Bar pct={result.confidence}/>
                  </div>

                  {/* Radar */}
                  <div style={{ height:152 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={radarData}>
                        <PolarGrid stroke="rgba(124,58,237,0.07)"/>
                        <PolarAngleAxis dataKey="s" tick={{ fontSize:9, fill:"#94a3b8" }}/>
                        <Radar name="Score" dataKey="v"
                          stroke="#7c3aed" fill="#7c3aed" fillOpacity={0.11} strokeWidth={1.8}/>
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Toggle all scores */}
                  <button onClick={() => setAll(!showAll)}
                    style={{ display:"flex", alignItems:"center", gap:4, background:"none",
                      border:"none", cursor:"pointer", fontSize:12, color:"#7c3aed",
                      fontWeight:600, padding:0, ...F }}>
                    {showAll ? <ChevronUp size={12}/> : <ChevronDown size={12}/>}
                    {showAll ? "Hide" : "Show"} all class scores
                  </button>

                  <AnimatePresence>
                    {showAll && (
                      <motion.div initial={{ height:0, opacity:0 }}
                        animate={{ height:"auto", opacity:1 }}
                        exit={{ height:0, opacity:0 }}
                        transition={{ duration:0.2 }}
                        style={{ overflow:"hidden" }}>
                        <div style={{ display:"flex", flexDirection:"column", gap:5, paddingTop:2 }}>
                          {CLASS_NAMES.map((name, i) => (
                            <div key={i} style={{ display:"flex", alignItems:"center", gap:7 }}>
                              <span style={{ fontSize:12, width:16 }}>{CLASS_EMOJIS[i]}</span>
                              <span style={{ fontSize:11, color:"#64748b", width:76, flexShrink:0 }}>{name}</span>
                              <div style={{ flex:1, height:3, background:"#f1f5f9", borderRadius:99, overflow:"hidden" }}>
                                <Bar pct={result.allScores[i]} active={i === result.classIdx} delay={i * 28}/>
                              </div>
                              <span style={{ fontSize:11, color:"#94a3b8", width:36, textAlign:"right" }}>
                                {result.allScores[i].toFixed(1)}%
                              </span>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <button
                    onClick={() => { setResult(null); setPrev(null); setAll(false); srcCanvas.current = null; }}
                    style={{ display:"flex", alignItems:"center", gap:5, background:"none",
                      border:"none", cursor:"pointer", fontSize:11, color:"#94a3b8",
                      padding:0, ...F, transition:"color 0.1s" }}
                    onMouseEnter={e => (e.currentTarget as HTMLElement).style.color = "#7c3aed"}
                    onMouseLeave={e => (e.currentTarget as HTMLElement).style.color = "#94a3b8"}>
                    <RefreshCcw size={11}/> Try another image
                  </button>
                </motion.div>
              )}

              {/* Empty state */}
              {!isLoading && !result && status !== "error" && (
                <motion.div key="empty" initial={{ opacity:0 }} animate={{ opacity:1 }}
                  style={{ background:"#ffffff", border:"1px solid rgba(0,0,0,0.07)",
                    borderRadius:22, padding:44, minHeight:300,
                    display:"flex", flexDirection:"column", alignItems:"center",
                    justifyContent:"center", gap:12, textAlign:"center", ...F }}>
                  <div style={{ width:50, height:50, borderRadius:13,
                    background:"rgba(124,58,237,0.06)", border:"1px solid rgba(124,58,237,0.10)",
                    display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <ImageIcon size={22} color="rgba(124,58,237,0.38)"/>
                  </div>
                  <p style={{ fontSize:14, color:"#94a3b8", maxWidth:218, lineHeight:1.58 }}>
                    {status === "ready"
                      ? "Drop an image or click a sample above — inference runs automatically."
                      : "Downloading the CIFAR-10 CNN model weights…"}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
