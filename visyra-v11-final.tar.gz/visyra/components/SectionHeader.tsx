/**
 * SectionHeader — shared section typography component.
 *
 * sub is optional — omit it for sections that look better without a subtitle
 * (e.g. ClassGallery, where the title stands alone).
 *
 * maxWidth is removed from subtitle — the subtitle now spans naturally to
 * align with the section's content container rather than orphaning at 440px.
 */
"use client";
import { motion } from "framer-motion";

interface Props {
  tag:    string;
  title:  string;
  sub?:   string;   // optional — omit to hide subtitle entirely
}

export default function SectionHeader({ tag, title, sub }: Props) {
  return (
    <motion.div
      initial={{ opacity:0, y:14 }}
      whileInView={{ opacity:1, y:0 }}
      viewport={{ once:true }}
      transition={{ duration:0.5, ease:[0.22,1,0.36,1] }}
      style={{ marginBottom:28 }}
    >
      <p style={{
        fontFamily: "-apple-system,'SF Pro Text','Inter',system-ui,sans-serif",
        fontSize: 12,
        fontWeight: 700,
        color: "#7c3aed",
        textTransform: "uppercase",
        letterSpacing: "0.15em",
        marginBottom: 9,
      }}>
        {tag}
      </p>

      <h2 style={{
        fontFamily: "-apple-system,'SF Pro Display','Inter',system-ui,sans-serif",
        fontSize: "clamp(1.9rem, 3.5vw, 2.65rem)",
        fontWeight: 800,
        letterSpacing: "-0.03em",
        color: "#09090e",
        lineHeight: 1.08,
      }}>
        {title}
      </h2>

      {sub && (
        <p style={{
          fontFamily: "-apple-system,'SF Pro Text','Inter',system-ui,sans-serif",
          marginTop: 9,
          fontSize: 15,
          color: "#64748b",
          lineHeight: 1.68,
        }}>
          {sub}
        </p>
      )}
    </motion.div>
  );
}
