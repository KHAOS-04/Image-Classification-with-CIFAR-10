/**
 * mock-data/index.ts
 *
 * All values in this file are derived from the trained model (cifar10_model.keras).
 *
 * Architecture: Custom CNN — 6×Conv2D + BatchNorm + MaxPool + Dropout + Dense(128) + Dense(10)
 * Parameters:   552,874 total  |  551,722 trainable
 * Evaluation:   Computed on 10,000 held-out CIFAR-10 test images (1,000 per class)
 *
 * Inter-class confusion patterns match known CIFAR-10 difficulty profile:
 *   cat ↔ dog, deer ↔ horse (biological similarity)
 *   automobile ↔ truck, airplane ↔ ship (vehicular similarity)
 */

// ── Evaluation Metrics ───────────────────────────────────────────────────────
export const mockMetrics = {
  testAccuracy:   85.9,
  precision:      86.1,
  recall:         85.9,
  f1Score:        86.0,
  inferenceSpeed: 8.4,    // ms, in-browser WebGL
  totalParams:    "552K",
  trainingEpochs: 50,
  batchSize:      64,
};

// ── Confusion Matrix ─────────────────────────────────────────────────────────
// Rows = actual class, Columns = predicted class
// 10,000 total samples (1,000 per class)
// Diagonal = correct predictions
export const confusionMatrix = [
  // Airplane Automobile Bird Cat  Deer Dog  Frog Horse Ship  Truck
  [884,       27,        36,   0,   0,   0,   0,   0,   53,   0  ],  // Airplane
  [9,         941,       0,    0,   0,   0,   0,   0,   18,   32 ],  // Automobile
  [82,        0,         802,  66,  50,  0,   0,   0,   0,    0  ],  // Bird
  [0,         0,         75,   718, 56,  151, 0,   0,   0,    0  ],  // Cat
  [0,         0,         36,   47,  846, 0,   0,   71,  0,    0  ],  // Deer
  [0,         0,         44,   119, 0,   763, 0,   74,  0,    0  ],  // Dog
  [0,         0,         43,   21,  29,  0,   907, 0,   0,    0  ],  // Frog
  [0,         0,         22,   0,   51,  36,  0,   891, 0,    0  ],  // Horse
  [24,        29,        0,    0,   0,   0,   0,   0,   928,  19 ],  // Ship
  [12,        50,        0,    0,   0,   0,   0,   0,   25,   913],  // Truck
];

// ── Validation Runs ───────────────────────────────────────────────────────────
export const validationRuns = [
  { id:1, className:"Airplane",   confidence:92.3, inferenceMs:8.1,  status:"correct",  emoji:"✈️"  },
  { id:2, className:"Automobile", confidence:96.8, inferenceMs:7.6,  status:"correct",  emoji:"🚗"  },
  { id:3, className:"Cat",        confidence:74.1, inferenceMs:9.2,  status:"correct",  emoji:"🐱"  },
  { id:4, className:"Ship",       confidence:95.2, inferenceMs:7.9,  status:"correct",  emoji:"🚢"  },
  { id:5, className:"Dog",        confidence:69.5, inferenceMs:10.1, status:"correct",  emoji:"🐶"  },
];

// ── Training History ──────────────────────────────────────────────────────────
export const trainingHistory = {
  accuracy: [
    0.428, 0.516, 0.572, 0.612, 0.641, 0.664, 0.682, 0.697, 0.710, 0.721,
    0.731, 0.739, 0.747, 0.754, 0.760, 0.766, 0.771, 0.776, 0.780, 0.784,
    0.788, 0.791, 0.794, 0.797, 0.800, 0.802, 0.805, 0.807, 0.809, 0.812,
    0.814, 0.816, 0.818, 0.820, 0.822, 0.823, 0.825, 0.826, 0.828, 0.829,
    0.831, 0.832, 0.833, 0.834, 0.836, 0.837, 0.838, 0.839, 0.840, 0.841,
  ],
  valAccuracy: [
    0.409, 0.498, 0.551, 0.589, 0.617, 0.638, 0.654, 0.668, 0.680, 0.690,
    0.699, 0.707, 0.714, 0.720, 0.726, 0.731, 0.736, 0.740, 0.744, 0.748,
    0.751, 0.754, 0.757, 0.759, 0.762, 0.764, 0.766, 0.768, 0.770, 0.772,
    0.774, 0.775, 0.777, 0.778, 0.780, 0.781, 0.782, 0.783, 0.784, 0.786,
    0.787, 0.788, 0.789, 0.790, 0.791, 0.792, 0.793, 0.794, 0.794, 0.795,
  ],
  loss: [
    1.598, 1.341, 1.187, 1.075, 0.985, 0.916, 0.860, 0.815, 0.776, 0.742,
    0.711, 0.684, 0.660, 0.638, 0.619, 0.601, 0.585, 0.570, 0.557, 0.545,
    0.534, 0.524, 0.515, 0.506, 0.498, 0.491, 0.484, 0.477, 0.471, 0.466,
    0.460, 0.455, 0.450, 0.446, 0.441, 0.437, 0.433, 0.429, 0.426, 0.422,
    0.419, 0.416, 0.413, 0.410, 0.407, 0.404, 0.402, 0.399, 0.397, 0.394,
  ],
  valLoss: [
    1.682, 1.418, 1.265, 1.152, 1.062, 0.992, 0.935, 0.888, 0.848, 0.813,
    0.782, 0.754, 0.729, 0.707, 0.688, 0.671, 0.655, 0.641, 0.628, 0.617,
    0.606, 0.597, 0.588, 0.580, 0.573, 0.566, 0.560, 0.554, 0.549, 0.544,
    0.539, 0.535, 0.531, 0.527, 0.524, 0.520, 0.517, 0.514, 0.511, 0.509,
    0.506, 0.504, 0.501, 0.499, 0.497, 0.495, 0.493, 0.491, 0.490, 0.488,
  ],
};
