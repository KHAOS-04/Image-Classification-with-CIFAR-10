/**
 * useModel.ts — TensorFlow.js inference hook for Visyra (CIFAR-10 CNN)
 *
 * Model: Custom CNN trained on CIFAR-10
 *   Conv2D(32)×2 → BN → MaxPool → Dropout(0.25)
 *   Conv2D(64)×2 → BN → MaxPool → Dropout(0.25)
 *   Conv2D(128)×2 → BN → MaxPool → Dropout(0.30)
 *   Flatten → Dense(128) → BN → Dropout(0.50) → Dense(10,softmax)
 *
 * Input:  Float32[1, 32, 32, 3]  pixels normalised to [0, 1]
 * Output: Float32[1, 10]         softmax class probabilities
 *
 * Key fixes vs previous version:
 * ──────────────────────────────
 * • predict() now accepts HTMLCanvasElement directly — avoids the HTMLImageElement
 *   async-onload timing race that caused 0.0% confidence scores.
 * • Preprocessing: single-pass uint8→float32 + normalise via div(255).
 *   resizeBilinear returns float32 — removed redundant .toFloat() call.
 * • drawToCanvas() helper: centralises all image-to-canvas drawing, used by
 *   both the upload path AND the sample-image path. One code path, one bug surface.
 * • Module-level model cache: model loads exactly once per browser session.
 * • WebGL→CPU backend fallback for Safari/iOS.
 * • Warm-up pass after load: compiles WebGL shaders before first real inference.
 */
"use client";
import { useState, useEffect, useCallback, useRef } from "react";

export const CLASS_NAMES = [
  "Airplane","Automobile","Bird","Cat","Deer",
  "Dog","Frog","Horse","Ship","Truck",
] as const;

export const CLASS_EMOJIS = [
  "✈️","🚗","🐦","🐱","🦌","🐶","🐸","🐴","🚢","🚛",
] as const;

const MODEL_URL   = "/model/model.json";
const IMG_SIZE    = 32;   // model input: 32×32
const N_CLASSES   = 10;
const MAX_RETRIES = 3;

export type ModelStatus = "idle" | "loading" | "ready" | "error";

export interface PredictResult {
  classIdx:    number;
  className:   string;
  emoji:       string;
  confidence:  number;   // 0–100
  allScores:   number[]; // [0–100] × 10
  inferenceMs: number;
}

type TF          = typeof import("@tensorflow/tfjs");
type LayersModel = import("@tensorflow/tfjs").LayersModel;

// Module-level singletons — survive React re-renders
let _tf:          TF           | null = null;
let _model:       LayersModel  | null = null;
let _loadPromise: Promise<void>| null = null;

// ── Shared offscreen canvas for pixel extraction ─────────────────────────────
// Using a single reusable OffscreenCanvas or regular canvas avoids repeated
// allocations and guarantees fromPixels always reads committed pixel data.
let _offscreen: HTMLCanvasElement | null = null;
let _offCtx:    CanvasRenderingContext2D | null = null;

function getOffscreenCanvas(): [HTMLCanvasElement, CanvasRenderingContext2D] {
  if (!_offscreen) {
    _offscreen = document.createElement("canvas");
    _offscreen.width  = IMG_SIZE;
    _offscreen.height = IMG_SIZE;
    _offCtx = _offscreen.getContext("2d", { willReadFrequently: true })!;
  }
  return [_offscreen, _offCtx!];
}

/**
 * drawToCanvas — draws ANY image source into a 32×32 canvas synchronously.
 * Returns the canvas, which can be passed directly to tf.browser.fromPixels.
 *
 * Accepts: HTMLImageElement | HTMLCanvasElement | HTMLVideoElement | ImageData | ImageBitmap
 */
export function drawToCanvas(
  source: HTMLImageElement | HTMLCanvasElement | HTMLVideoElement | ImageData | ImageBitmap
): HTMLCanvasElement {
  const [canvas, ctx] = getOffscreenCanvas();
  ctx.clearRect(0, 0, IMG_SIZE, IMG_SIZE);
  if (source instanceof ImageData) {
    ctx.putImageData(
      source.width === IMG_SIZE && source.height === IMG_SIZE
        ? source
        : (() => { const tmp = document.createElement("canvas"); tmp.width=source.width; tmp.height=source.height; tmp.getContext("2d")!.putImageData(source,0,0); return tmp; })(),
      0, 0
    );
  } else {
    ctx.drawImage(source as CanvasImageSource, 0, 0, IMG_SIZE, IMG_SIZE);
  }
  return canvas;
}

// ── Model loading ────────────────────────────────────────────────────────────
async function ensureLoaded(onProgress: (pct: number) => void): Promise<void> {
  if (_model) { onProgress(100); return; }
  if (_loadPromise) return _loadPromise;

  _loadPromise = (async () => {
    onProgress(5);
    _tf = await import("@tensorflow/tfjs");
    onProgress(20);

    // WebGL preferred; CPU fallback for iOS Safari / low-end devices
    try {
      await _tf.setBackend("webgl");
      await _tf.ready();
    } catch {
      await _tf.setBackend("cpu");
      await _tf.ready();
    }
    onProgress(30);

    let lastErr: unknown;
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        _model = await _tf.loadLayersModel(MODEL_URL, {
          onProgress: (f) => onProgress(30 + Math.round(f * 62)),
        });

        // Warm-up: forces WebGL shader compilation once
        const warmup = _tf.zeros([1, IMG_SIZE, IMG_SIZE, 3]);
        (_model.predict(warmup) as import("@tensorflow/tfjs").Tensor).dispose();
        warmup.dispose();

        onProgress(100);
        if (process.env.NODE_ENV === "development") {
          console.info(
            `[Visyra] CNN loaded | backend=${_tf.getBackend()} | params=${_model.countParams().toLocaleString()}`
          );
        }
        return;
      } catch (err) {
        lastErr = err;
        if (process.env.NODE_ENV === "development")
          console.warn(`[Visyra] Load attempt ${attempt}/${MAX_RETRIES}:`, err);
        if (attempt < MAX_RETRIES)
          await new Promise(r => setTimeout(r, 500 * attempt));
      }
    }
    _loadPromise = null;
    throw lastErr;
  })();

  return _loadPromise;
}

// ── Hook ─────────────────────────────────────────────────────────────────────
export function useModel() {
  const [status,  setStatus]  = useState<ModelStatus>(_model ? "ready" : "idle");
  const [loadPct, setLoadPct] = useState(_model ? 100 : 0);
  const mounted = useRef(true);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);

  const load = useCallback(async () => {
    if (_model) { setStatus("ready"); setLoadPct(100); return; }
    if (status === "loading") return;
    setStatus("loading"); setLoadPct(0);
    try {
      await ensureLoaded(p => { if (mounted.current) setLoadPct(p); });
      if (mounted.current) { setStatus("ready"); setLoadPct(100); }
    } catch {
      if (mounted.current) setStatus("error");
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * predict — runs inference on any drawable image source.
   *
   * The source is first drawn into a 32×32 canvas via drawToCanvas().
   * This is the ONLY entry point for pixels — guarantees consistent
   * preprocessing for uploads, samples, and anything else.
   *
   * Preprocessing matches training:
   *   pixels uint8 [0,255] → float32 → divide by 255 → [0,1]
   */
  const predict = useCallback(async (
    source: HTMLImageElement | HTMLCanvasElement | HTMLVideoElement | ImageData | ImageBitmap
  ): Promise<PredictResult | null> => {
    if (!_model || !_tf) return null;

    const t0 = performance.now();

    // 1. Draw source into the shared 32×32 canvas (always synchronous)
    const canvas = drawToCanvas(source);

    // 2. All tensor ops in a single tidy block
    const rawScores = _tf.tidy((): number[] => {
      // fromPixels on a canvas is always synchronous and always correct
      const pixels  = _tf!.browser.fromPixels(canvas);          // [32,32,3] uint8
      const norm    = pixels.div(_tf!.scalar(255));              // [32,32,3] float32 [0,1]
      const batched = norm.expandDims(0) as import("@tensorflow/tfjs").Tensor4D; // [1,32,32,3]
      const output  = _model!.predict(batched) as import("@tensorflow/tfjs").Tensor2D;
      return Array.from(output.dataSync());
    });

    if (rawScores.length !== N_CLASSES) return null;

    const inferenceMs = Math.round(performance.now() - t0);
    const classIdx    = rawScores.indexOf(Math.max(...rawScores));
    const allScores   = rawScores.map(v => parseFloat((v * 100).toFixed(1)));

    return {
      classIdx,
      className:  CLASS_NAMES[classIdx],
      emoji:      CLASS_EMOJIS[classIdx],
      confidence: allScores[classIdx],
      allScores,
      inferenceMs,
    };
  }, []);

  return { status, loadPct, load, predict, CLASS_NAMES, CLASS_EMOJIS };
}
