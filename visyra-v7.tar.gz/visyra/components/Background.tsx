"use client";
import { useEffect, useRef } from "react";

export default function Background() {
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  // Three cursor-reactive gradient orbs at different speeds
  const glowARef   = useRef<HTMLDivElement>(null);  // primary — fastest
  const glowBRef   = useRef<HTMLDivElement>(null);  // secondary — slower
  const meshRef    = useRef<HTMLDivElement>(null);  // mesh overlay shift
  const mouse      = useRef({ x: 0.5, y: 0.5 });
  const posA       = useRef({ x: 0.5, y: 0.5 });
  const posB       = useRef({ x: 0.5, y: 0.5 });
  const posMesh    = useRef({ x: 0.5, y: 0.5 });
  const target     = useRef({ x: 0.5, y: 0.5 });

  useEffect(() => {
    const isMobile = window.matchMedia("(hover: none), (max-width: 768px)").matches;

    /* ── Mouse tracking ─────────────────────── */
    const onMove = (e: MouseEvent) => {
      target.current.x = e.clientX / window.innerWidth;
      target.current.y = e.clientY / window.innerHeight;
    };
    if (!isMobile) {
      window.addEventListener("mousemove", onMove, { passive: true });
    }

    /* ── Glow + mesh rAF loop ────────────────
       Three layers lerp at different speeds for parallax depth.
       All writes go to transform: translate3d — compositor only.
    ───────────────────────────────────────── */
    let glowRaf = 0;
    const LERP_A    = 0.08;   // primary glow — responsive
    const LERP_B    = 0.04;   // secondary — sluggish, dreamy
    const LERP_MESH = 0.025;  // mesh — very slow drift

    const tickGlow = () => {
      glowRaf = requestAnimationFrame(tickGlow);

      const tx = target.current.x;
      const ty = target.current.y;

      // Layer A
      const dxA = tx - posA.current.x, dyA = ty - posA.current.y;
      if (Math.abs(dxA) > 0.0003 || Math.abs(dyA) > 0.0003) {
        posA.current.x += dxA * LERP_A;
        posA.current.y += dyA * LERP_A;
        const elA = glowARef.current;
        if (elA) {
          // Shift center ±18% of viewport based on cursor
          const offX = (posA.current.x - 0.5) * 36;
          const offY = (posA.current.y - 0.5) * 28;
          elA.style.transform = `translate3d(calc(-50% + ${offX.toFixed(1)}vw), calc(-50% + ${offY.toFixed(1)}vh), 0)`;
        }
      }

      // Layer B
      const dxB = tx - posB.current.x, dyB = ty - posB.current.y;
      if (Math.abs(dxB) > 0.0002 || Math.abs(dyB) > 0.0002) {
        posB.current.x += dxB * LERP_B;
        posB.current.y += dyB * LERP_B;
        const elB = glowBRef.current;
        if (elB) {
          const offX = (posB.current.x - 0.5) * -22;
          const offY = (posB.current.y - 0.5) * -18;
          elB.style.transform = `translate3d(calc(-50% + ${offX.toFixed(1)}vw), calc(-50% + ${offY.toFixed(1)}vh), 0)`;
        }
      }

      // Mesh overlay
      const dxM = tx - posMesh.current.x, dyM = ty - posMesh.current.y;
      if (Math.abs(dxM) > 0.0001 || Math.abs(dyM) > 0.0001) {
        posMesh.current.x += dxM * LERP_MESH;
        posMesh.current.y += dyM * LERP_MESH;
        const elM = meshRef.current;
        if (elM) {
          // Shift mesh gradient focal point
          const px = (posMesh.current.x * 100).toFixed(1);
          const py = (posMesh.current.y * 100).toFixed(1);
          elM.style.background = [
            `radial-gradient(ellipse 90% 55% at ${px}% -5%, rgba(196,181,253,0.46) 0%, transparent 65%)`,
            `radial-gradient(ellipse 38% 28% at ${(100-Number(px)*.4).toFixed(0)}% 95%, rgba(192,38,211,0.07) 0%, transparent 60%)`,
            `radial-gradient(ellipse 34% 26% at 6% ${(100-Number(py)*.5).toFixed(0)}%, rgba(79,70,229,0.06) 0%, transparent 58%)`,
          ].join(", ");
        }
      }
    };
    glowRaf = requestAnimationFrame(tickGlow);

    /* ── Neural particle canvas ─────────────── */
    const canvas = canvasRef.current;
    const ctx    = canvas?.getContext("2d", { alpha: true });
    if (!canvas || !ctx) return;

    const isLowEnd = navigator.hardwareConcurrency <= 2;
    const N    = isMobile || isLowEnd ? 16 : 42;
    const DIST = isMobile ? 95 : 118;
    const FPS  = isMobile ? 30 : 60;
    const FRAME_MS = 1000 / FPS;

    let W = 0, H = 0;
    const resize = () => { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; };
    resize();
    window.addEventListener("resize", resize, { passive: true });

    type P = { x:number; y:number; vx:number; vy:number; a:number; r:number };
    const pts: P[] = Array.from({ length: N }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      vx: (Math.random() - 0.5) * 0.18,
      vy: (Math.random() - 0.5) * 0.18,
      a: Math.random() * 0.12 + 0.03,
      r: Math.random() * 1.3 + 0.4,
    }));

    let canvasRaf = 0;
    let lastFrame = 0;
    const visRef  = { current: true };
    const io = new IntersectionObserver(([e]) => { visRef.current = e.isIntersecting; });
    io.observe(canvas);

    const drawCanvas = (ts: number) => {
      canvasRaf = requestAnimationFrame(drawCanvas);
      if (!visRef.current || ts - lastFrame < FRAME_MS) return;
      lastFrame = ts;
      ctx.clearRect(0, 0, W, H);

      // Connections — desktop only (d² avoids sqrt for most pairs)
      if (!isMobile) {
        const DIST2 = DIST * DIST;
        for (let i = 0; i < N; i++) {
          for (let j = i + 1; j < N; j++) {
            const dx = pts[i].x - pts[j].x;
            const dy = pts[i].y - pts[j].y;
            const d2 = dx * dx + dy * dy;
            if (d2 < DIST2) {
              const d = Math.sqrt(d2);
              ctx.beginPath();
              ctx.strokeStyle = `rgba(124,58,237,${(0.032*(1-d/DIST)).toFixed(3)})`;
              ctx.lineWidth = 0.5;
              ctx.moveTo(pts[i].x, pts[i].y);
              ctx.lineTo(pts[j].x, pts[j].y);
              ctx.stroke();
            }
          }
        }
      }

      for (const p of pts) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = W; else if (p.x > W) p.x = 0;
        if (p.y < 0) p.y = H; else if (p.y > H) p.y = 0;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(124,58,237,${p.a})`;
        ctx.fill();
      }
    };
    canvasRaf = requestAnimationFrame(drawCanvas);

    const onVis = () => {
      if (document.hidden) {
        cancelAnimationFrame(canvasRaf);
        cancelAnimationFrame(glowRaf);
      } else {
        canvasRaf = requestAnimationFrame(drawCanvas);
        glowRaf   = requestAnimationFrame(tickGlow);
      }
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      cancelAnimationFrame(canvasRaf);
      cancelAnimationFrame(glowRaf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMove);
      document.removeEventListener("visibilitychange", onVis);
      io.disconnect();
    };
  }, []);

  return (
    <div aria-hidden="true" style={{ position:"fixed", inset:0, zIndex:-10, pointerEvents:"none", overflow:"hidden" }}>
      {/* Base */}
      <div style={{ position:"absolute", inset:0, background:"#f7f7f9" }}/>

      {/* Dynamic mesh gradient — shifts with cursor */}
      <div ref={meshRef} style={{
        position:"absolute", inset:0, pointerEvents:"none",
        background:[
          "radial-gradient(ellipse 90% 55% at 50% -5%, rgba(196,181,253,0.46) 0%, transparent 65%)",
          "radial-gradient(ellipse 38% 28% at 85% 95%, rgba(192,38,211,0.07) 0%, transparent 60%)",
          "radial-gradient(ellipse 34% 26% at 6% 72%,  rgba(79,70,229,0.06) 0%, transparent 58%)",
        ].join(", "),
        willChange:"background",
        transition:"background 0.6s ease",
      }}/>

      {/* Static aurora blobs — CSS animated */}
      <div className="bg-aurora-a" style={{
        position:"absolute", top:"-18%", left:"-8%",
        width:"70vw", height:"70vw", borderRadius:"50%",
        background:"radial-gradient(ellipse, rgba(167,139,250,0.44) 0%, rgba(124,58,237,0.20) 32%, transparent 68%)",
        filter:"blur(60px)", willChange:"transform",
      }}/>
      <div className="bg-aurora-b" style={{
        position:"absolute", bottom:"-14%", right:"-8%",
        width:"58vw", height:"58vw", borderRadius:"50%",
        background:"radial-gradient(ellipse, rgba(192,38,211,0.10) 0%, rgba(139,92,246,0.06) 36%, transparent 66%)",
        filter:"blur(72px)", willChange:"transform",
      }}/>
      <div className="bg-aurora-c" style={{
        position:"absolute", top:"38%", left:"55%",
        width:"44vw", height:"44vw", borderRadius:"50%",
        background:"radial-gradient(ellipse, rgba(79,70,229,0.07) 0%, transparent 65%)",
        filter:"blur(80px)", willChange:"transform",
      }}/>

      {/* Cursor-reactive glow A — primary, faster */}
      <div ref={glowARef} style={{
        position:"absolute", top:"50%", left:"50%",
        width:"56vw", height:"56vw", borderRadius:"50%",
        background:"radial-gradient(circle, rgba(124,58,237,0.075) 0%, rgba(139,92,246,0.04) 42%, transparent 68%)",
        filter:"blur(52px)",
        transform:"translate3d(-50%,-50%,0)",
        willChange:"transform",
      }}/>

      {/* Cursor-reactive glow B — secondary, slower, complementary color */}
      <div ref={glowBRef} style={{
        position:"absolute", top:"50%", left:"50%",
        width:"48vw", height:"48vw", borderRadius:"50%",
        background:"radial-gradient(circle, rgba(192,38,211,0.045) 0%, rgba(124,58,237,0.025) 48%, transparent 72%)",
        filter:"blur(68px)",
        transform:"translate3d(-50%,-50%,0)",
        willChange:"transform",
      }}/>

      {/* Particle canvas */}
      <canvas ref={canvasRef} style={{ position:"absolute", inset:0, opacity:0.48, mixBlendMode:"multiply" }}/>
    </div>
  );
}
