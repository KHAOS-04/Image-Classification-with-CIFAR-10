"use client";
import { useEffect, useRef } from "react";

/**
 * Premium black dot cursor + trailing ring.
 * Both elements are positioned via translate3d on a single rAF loop.
 * The dot follows instantly; the ring lags slightly for a trailing effect.
 * On mobile / touch devices: hidden (CSS cursor:auto restored via media query).
 */
export default function Cursor() {
  const dotRef  = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Skip on touch devices
    if (window.matchMedia("(hover: none)").matches) return;

    const dot  = dotRef.current;
    const ring = ringRef.current;
    if (!dot || !ring) return;

    let mx = -100, my = -100;   // off-screen until first move
    let rx = -100, ry = -100;
    let raf = 0;
    let isHover = false;

    const onMove = (e: MouseEvent) => {
      mx = e.clientX;
      my = e.clientY;
    };

    // Detect hover over interactive elements
    const onEnter = (e: MouseEvent) => {
      const el = e.target as HTMLElement;
      if (el.closest("a,button,[role=button],input,select,textarea,label")) {
        isHover = true;
      }
    };
    const onLeave = (e: MouseEvent) => {
      const el = e.target as HTMLElement;
      if (el.closest("a,button,[role=button],input,select,textarea,label")) {
        isHover = false;
      }
    };

    window.addEventListener("mousemove",  onMove,  { passive: true });
    document.addEventListener("mouseover", onEnter, { passive: true });
    document.addEventListener("mouseout",  onLeave, { passive: true });

    const RING_LERP = 0.14;  // ring lag: lower = more trail

    const tick = () => {
      raf = requestAnimationFrame(tick);

      // Dot — instant follow
      dot.style.transform  = `translate3d(${mx - 4}px, ${my - 4}px, 0)`;

      // Ring — lags behind
      rx += (mx - rx) * RING_LERP;
      ry += (my - ry) * RING_LERP;
      ring.style.transform = `translate3d(${rx - 16}px, ${ry - 16}px, 0)`;

      // Scale ring on hover
      const scale = isHover ? "scale(1.6)" : "scale(1)";
      ring.style.transform += ` ${scale}`;
    };

    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("mousemove",  onMove);
      document.removeEventListener("mouseover", onEnter);
      document.removeEventListener("mouseout",  onLeave);
    };
  }, []);

  return (
    <>
      {/* Dot — small, black, instant */}
      <div
        ref={dotRef}
        aria-hidden="true"
        style={{
          position: "fixed",
          top: 0, left: 0,
          width: 8, height: 8,
          borderRadius: "50%",
          background: "#09090e",
          pointerEvents: "none",
          zIndex: 9999,
          transform: "translate3d(-100px,-100px,0)",
          willChange: "transform",
          transition: "opacity 0.2s",
        }}
      />
      {/* Ring — larger, trails behind */}
      <div
        ref={ringRef}
        aria-hidden="true"
        style={{
          position: "fixed",
          top: 0, left: 0,
          width: 32, height: 32,
          borderRadius: "50%",
          border: "1.5px solid rgba(9,9,14,0.35)",
          pointerEvents: "none",
          zIndex: 9998,
          transform: "translate3d(-100px,-100px,0)",
          willChange: "transform",
          transition: "transform 0.12s cubic-bezier(0.22,1,0.36,1), border-color 0.15s",
        }}
      />
    </>
  );
}
