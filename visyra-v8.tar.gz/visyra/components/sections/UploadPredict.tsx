"use client";
import { useState, useRef, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload, RefreshCcw, CheckCircle2, Image as ImageIcon,
  ChevronDown, ChevronUp, Sparkles, Brain, AlertTriangle,
} from "lucide-react";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer } from "recharts";
import { CIFAR10_CLASSES } from "@/constants/cifar10";
import { useModel } from "@/lib/useModel";

const SAMPLE_CLASSES = [0,5,3,8,7,9]; // airplane,dog,cat,ship,horse,truck
const SAMPLE_LABELS  = ["Airplane","Dog","Cat","Ship","Horse","Truck"];
const SAMPLE_EMOJIS  = ["✈️","🐶","🐱","🚢","🐴","🚛"];

// CIFAR-10 sample colours for placeholder images
const SAMPLE_COLORS = [
  "#4f46e5","#7c3aed","#c026d3","#0891b2","#059669","#d97706",
];

const LOAD_MSGS = [
  "Loading MobileNetV2 weights…",
  "Initialising TensorFlow.js…",
  "Preprocessing image to 32×32…",
  "Running forward pass…",
  "Applying softmax…",
];

const INFER_MSGS = [
  "Resizing to 32×32…",
  "Normalising pixels…",
  "Running MobileNetV2…",
  "Computing softmax…",
  "Finalising scores…",
];

function Bar({ pct, active=true, delay=0 }: { pct:number; active?:boolean; delay?:number }) {
  return (
    <motion.div
      initial={{ width:0 }} animate={{ width:`${pct}%` }}
      transition={{ duration:0.7,delay:delay/1000,ease:[0.22,1,0.36,1] }}
      style={{
        height:"100%",borderRadius:99,
        background:active?"linear-gradient(90deg,#6d28d9,#a855f7)":"rgba(124,58,237,0.2)",
      }}
    />
  );
}

function CountUp({ to, suffix="" }: { to:number; suffix?:string }) {
  const [v,setV] = useState(0);
  const [started,setStarted] = useState(false);
  if (!started) {
    setStarted(true);
    setTimeout(()=>{
      let c=0; const iv=setInterval(()=>{ c+=to/36; if(c>=to){setV(to);clearInterval(iv);}else setV(c); },750/36);
    },60);
  }
  return <>{v.toFixed(1)}{suffix}</>;
}

export default function UploadPredict() {
  const { status, loadPct, load, predict, CLASS_NAMES, CLASS_EMOJIS } = useModel();

  const [drag,   setDrag]   = useState(false);
  const [preview,setPrev]   = useState<string|null>(null);
  const [imgEl,  setImgEl]  = useState<HTMLImageElement|null>(null);
  const [running,setRun]    = useState(false);
  const [msgIdx, setMsg]    = useState(0);
  const [result, setResult] = useState<Awaited<ReturnType<typeof predict>>|null>(null);
  const [showAll,setAll]    = useState(false);
  const [dropGlow, setDropGlow] = useState(false);  // hover glow state
  const inputRef  = useRef<HTMLInputElement>(null);
  const imgRef    = useRef<HTMLImageElement>(null);

  // Pre-warm model on mount
  useEffect(() => { load(); }, [load]);

  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = e => {
      const src = e.target?.result as string;
      setPrev(src);
      setResult(null);
      setAll(false);
      // Create a hidden img element for tfjs fromPixels
      const img = new Image();
      img.onload = () => setImgEl(img);
      img.src = src;
    };
    reader.readAsDataURL(file);
  }, []);

  const runInference = useCallback(async (sampleClassId?: number) => {
    setRun(true); setResult(null); setAll(false);

    // Animate messages through inference steps
    let msgI = 0;
    const msgInterval = setInterval(() => {
      setMsg(msgI % INFER_MSGS.length);
      msgI++;
    }, 400);

    try {
      let el: HTMLImageElement | null = null;

      if (sampleClassId !== undefined) {
        // Generate a solid-colour canvas as a placeholder "sample"
        const canvas = document.createElement("canvas");
        canvas.width = 32; canvas.height = 32;
        const ctx = canvas.getContext("2d")!;
        ctx.fillStyle = SAMPLE_COLORS[SAMPLE_CLASSES.indexOf(sampleClassId)] ?? "#7c3aed";
        ctx.fillRect(0,0,32,32);
        // Add some noise for realism
        for (let i=0;i<200;i++) {
          ctx.fillStyle = `rgba(255,255,255,${Math.random()*0.2})`;
          ctx.fillRect(Math.random()*32,Math.random()*32,Math.random()*4,Math.random()*4);
        }
        // Convert canvas to img element
        const src = canvas.toDataURL();
        setPrev(src);
        el = new Image();
        el.src = src;
        await new Promise(r => { el!.onload=r; });
      } else {
        el = imgEl;
      }

      if (!el) { setRun(false); clearInterval(msgInterval); return; }

      const res = await predict(el);
      clearInterval(msgInterval);
      setResult(res);
    } catch(e) {
      clearInterval(msgInterval);
      console.error(e);
    }
    setRun(false);
  }, [imgEl, predict]);

  const radar = result
    ? CLASS_NAMES.map((n,i) => ({ s:n, v:result.allScores[i] }))
    : [];

  const S: React.CSSProperties = { fontFamily:"-apple-system,'SF Pro Text','Inter',sans-serif" };

  // Determine message sequence for loading
  const loadingMsg = running
    ? INFER_MSGS[msgIdx % INFER_MSGS.length]
    : status === "loading"
      ? LOAD_MSGS[Math.min(Math.floor(loadPct/25), LOAD_MSGS.length-1)]
      : "";

  const isLoading = running || status === "loading";

  return (
    <section id="predict" style={{ padding:"52px 20px" }}>
      <div style={{ maxWidth:1040, margin:"0 auto" }}>

        {/* Header */}
        <motion.div initial={{ opacity:0,y:14 }} whileInView={{ opacity:1,y:0 }}
          viewport={{ once:true }} transition={{ duration:0.5 }}
          style={{ marginBottom:28 }}>
          <p style={{ fontSize:12,fontWeight:700,color:"#7c3aed",textTransform:"uppercase",letterSpacing:"0.14em",marginBottom:9 }}>
            Neural Inference
          </p>
          <h2 style={{ fontSize:"clamp(1.9rem,3.5vw,2.65rem)",fontWeight:800,letterSpacing:"-0.03em",color:"#09090e",lineHeight:1.08 }}>
            Classify an Image
          </h2>
          <p style={{ marginTop:9,fontSize:15,color:"#64748b",lineHeight:1.68,maxWidth:420 }}>
            Upload any image — the MobileNetV2 CNN predicts its CIFAR-10 class in real time.
          </p>

          {/* Model status chip */}
          <div style={{ marginTop:12,display:"inline-flex",alignItems:"center",gap:6,
            background:status==="ready"?"rgba(16,185,129,0.08)":status==="error"?"rgba(239,68,68,0.08)":"rgba(124,58,237,0.07)",
            border:`1px solid ${status==="ready"?"rgba(16,185,129,0.2)":status==="error"?"rgba(239,68,68,0.2)":"rgba(124,58,237,0.15)"}`,
            borderRadius:20,padding:"4px 12px" }}>
            <div style={{ width:6,height:6,borderRadius:"50%",flexShrink:0,
              background:status==="ready"?"#10b981":status==="error"?"#ef4444":"#7c3aed",
              ...(status==="loading"?{ animation:"pulse-dot 1.5s ease-out infinite" }:{}) }}/>
            <span style={{ fontSize:11,fontWeight:600,
              color:status==="ready"?"#059669":status==="error"?"#dc2626":"#6d28d9",...S }}>
              {status==="ready" ? "MobileNetV2 loaded · ready"
               : status==="loading" ? `Loading model… ${loadPct}%`
               : status==="error" ? "Model failed to load"
               : "Initialising…"}
            </span>
          </div>
        </motion.div>

        {/* Bento grid */}
        <div style={{ display:"grid",gridTemplateColumns:"minmax(0,1fr) minmax(0,1fr)",gap:12 }}
          className="max-md:block">

          {/* LEFT: dark upload card + samples */}
          <motion.div initial={{ opacity:0,x:-14 }} whileInView={{ opacity:1,x:0 }}
            viewport={{ once:true }} transition={{ duration:0.48 }}
            style={{ display:"flex",flexDirection:"column",gap:10 }}
            className="max-md:mb-3">

            {/* ── Dropzone — dark card with hover glow ── */}
            <div
              style={{
                background:"#0c0c14",
                border:`1.5px dashed ${drag
                  ? "rgba(124,58,237,0.8)"
                  : dropGlow
                    ? "rgba(124,58,237,0.45)"
                    : "rgba(255,255,255,0.10)"}`,
                borderRadius:22,padding:"36px 28px",minHeight:188,
                display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
                cursor:"pointer",position:"relative",overflow:"hidden",
                transition:"border-color 0.18s, box-shadow 0.22s",
                /* ── GLOW EFFECT on hover ── */
                boxShadow: dropGlow || drag
                  ? "0 0 0 1px rgba(124,58,237,0.2), 0 0 32px rgba(124,58,237,0.22), inset 0 0 32px rgba(124,58,237,0.08)"
                  : "none",
              }}
              onMouseEnter={() => setDropGlow(true)}
              onMouseLeave={() => setDropGlow(false)}
              onDragOver={e=>{ e.preventDefault(); setDrag(true); setDropGlow(true); }}
              onDragLeave={()=>{ setDrag(false); setDropGlow(false); }}
              onDrop={e=>{
                e.preventDefault(); setDrag(false); setDropGlow(false);
                const f=e.dataTransfer.files[0]; if(f) handleFile(f);
              }}
              onClick={()=>inputRef.current?.click()}
            >
              {/* Ambient inner glow — intensifies on hover */}
              <div style={{
                position:"absolute",top:"-20%",left:"15%",width:"70%",height:"120%",
                borderRadius:"50%",pointerEvents:"none",filter:"blur(10px)",
                background: dropGlow || drag
                  ? "radial-gradient(ellipse,rgba(124,58,237,0.28) 0%,transparent 70%)"
                  : "radial-gradient(ellipse,rgba(124,58,237,0.12) 0%,transparent 70%)",
                transition:"background 0.22s",
              }}/>

              <input ref={inputRef} type="file" accept="image/*" style={{ display:"none" }}
                onChange={e=>{ const f=e.target.files?.[0]; if(f) handleFile(f); }}/>

              {preview ? (
                <div style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:10,position:"relative" }}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={preview} alt="preview" ref={imgRef}
                    style={{ width:92,height:92,objectFit:"cover",borderRadius:14,
                      boxShadow:"0 8px 28px rgba(0,0,0,0.55)",
                      imageRendering:"pixelated" }}/>
                  <span style={{ fontSize:12,color:"rgba(255,255,255,0.35)",...S }}>Click to change</span>
                </div>
              ) : (
                <div style={{ textAlign:"center",position:"relative" }}>
                  <motion.div animate={{ scale:drag?1.12:dropGlow?1.05:1 }}
                    transition={{ duration:0.18 }}
                    style={{ width:52,height:52,borderRadius:14,margin:"0 auto 14px",
                      background: dropGlow||drag?"rgba(124,58,237,0.28)":"rgba(124,58,237,0.16)",
                      border:`1px solid ${dropGlow||drag?"rgba(124,58,237,0.5)":"rgba(124,58,237,0.28)"}`,
                      display:"flex",alignItems:"center",justifyContent:"center",
                      boxShadow: dropGlow||drag?"0 0 20px rgba(124,58,237,0.3)":"none",
                      transition:"all 0.18s",
                    }}>
                    <Upload size={21} color={dropGlow||drag?"rgba(196,181,253,1)":"rgba(196,181,253,0.85)"}/>
                  </motion.div>
                  <p style={{ fontSize:15,fontWeight:600,color:"rgba(255,255,255,0.85)",marginBottom:4,...S }}>
                    Drop your image here
                  </p>
                  <p style={{ fontSize:13,color:"rgba(255,255,255,0.3)",...S }}>
                    or click to browse · JPG PNG WebP
                  </p>
                </div>
              )}
            </div>

            {/* Run button */}
            <AnimatePresence>
              {preview && !isLoading && status === "ready" && (
                <motion.button
                  initial={{ opacity:0,y:5 }} animate={{ opacity:1,y:0 }} exit={{ opacity:0 }}
                  transition={{ duration:0.18 }}
                  whileHover={{ scale:1.015 }} whileTap={{ scale:0.97 }}
                  onClick={() => runInference()}
                  style={{ border:"none",cursor:"pointer",borderRadius:16,padding:"13px",
                    background:"linear-gradient(135deg,#7c3aed,#5b21b6)",
                    color:"white",fontSize:13,fontWeight:700,...S,
                    boxShadow:"0 0 24px rgba(124,58,237,0.38)",
                    display:"flex",alignItems:"center",justifyContent:"center",gap:7 }}>
                  <Sparkles size={14}/> Run Real Inference
                </motion.button>
              )}
            </AnimatePresence>

            {/* Sample images */}
            <div>
              <p style={{ fontSize:11,fontWeight:700,color:"#94a3b8",textTransform:"uppercase",
                letterSpacing:"0.14em",marginBottom:9,...S }}>Try a sample</p>
              <div style={{ display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:7 }}>
                {SAMPLE_LABELS.map((label,i) => (
                  <motion.button key={i}
                    whileHover={{ y:-3 }} whileTap={{ scale:0.95 }}
                    transition={{ duration:0.1 }}
                    onClick={()=>{ setResult(null); runInference(SAMPLE_CLASSES[i]); }}
                    disabled={status !== "ready"}
                    style={{ background:"#ffffff",border:"1px solid rgba(0,0,0,0.07)",
                      borderRadius:13,padding:"9px 4px",
                      display:"flex",flexDirection:"column",alignItems:"center",gap:3,
                      cursor:status==="ready"?"pointer":"not-allowed",
                      opacity:status==="ready"?1:0.5,
                      boxShadow:"0 1px 4px rgba(0,0,0,0.05)",...S }}>
                    <span style={{ fontSize:17 }}>{SAMPLE_EMOJIS[i]}</span>
                    <span style={{ fontSize:11,fontWeight:600,color:"#374151" }}>{label}</span>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>

          {/* RIGHT: result panel */}
          <motion.div initial={{ opacity:0,x:14 }} whileInView={{ opacity:1,x:0 }}
            viewport={{ once:true }} transition={{ duration:0.48,delay:0.07 }}>
            <AnimatePresence mode="wait">

              {/* Loading / Inference running */}
              {isLoading && (
                <motion.div key="load"
                  initial={{ opacity:0,scale:0.97 }} animate={{ opacity:1,scale:1 }}
                  exit={{ opacity:0,scale:0.97 }} transition={{ duration:0.18 }}
                  style={{ background:"#ffffff",border:"1px solid rgba(0,0,0,0.07)",
                    borderRadius:22,padding:36,minHeight:300,
                    display:"flex",flexDirection:"column",alignItems:"center",
                    justifyContent:"center",gap:18,...S }}>
                  <div style={{ position:"relative",width:52,height:52,display:"flex",alignItems:"center",justifyContent:"center" }}>
                    <div className="anim-spin-cw" style={{ position:"absolute",inset:0,borderRadius:"50%",
                      border:"2px solid transparent",borderTop:"2px solid #7c3aed" }}/>
                    <div className="anim-spin-ccw" style={{ position:"absolute",inset:7,borderRadius:"50%",
                      border:"2px solid transparent",borderBottom:"2px solid #c4b5fd" }}/>
                    <Brain size={14} color="#7c3aed"/>
                  </div>
                  <div style={{ textAlign:"center" }}>
                    <p style={{ fontSize:14,fontWeight:600,color:"#374151",marginBottom:3 }}>{loadingMsg}</p>
                    <p style={{ fontSize:12,color:"#94a3b8" }}>
                      {status==="loading" ? `MobileNetV2 · ${loadPct}%` : "Real-time inference · TF.js"}
                    </p>
                  </div>
                  {status==="loading" && (
                    <div style={{ width:120,height:3,background:"#f1f5f9",borderRadius:99,overflow:"hidden" }}>
                      <motion.div animate={{ width:`${loadPct}%` }}
                        transition={{ duration:0.3 }}
                        style={{ height:"100%",borderRadius:99,
                          background:"linear-gradient(90deg,#7c3aed,#a855f7)" }}/>
                    </div>
                  )}
                  {running && (
                    <div style={{ width:90,height:3,borderRadius:99,overflow:"hidden" }}>
                      <div className="shimmer-bar" style={{ width:"100%",height:"100%" }}/>
                    </div>
                  )}
                </motion.div>
              )}

              {/* Error state */}
              {status === "error" && !isLoading && (
                <motion.div key="err"
                  initial={{ opacity:0 }} animate={{ opacity:1 }}
                  style={{ background:"rgba(239,68,68,0.04)",border:"1px solid rgba(239,68,68,0.15)",
                    borderRadius:22,padding:36,minHeight:300,
                    display:"flex",flexDirection:"column",alignItems:"center",
                    justifyContent:"center",gap:10,textAlign:"center",...S }}>
                  <AlertTriangle size={28} color="#ef4444"/>
                  <p style={{ fontSize:14,fontWeight:600,color:"#dc2626" }}>Model failed to load</p>
                  <p style={{ fontSize:13,color:"#94a3b8",maxWidth:220 }}>
                    Check your network connection and refresh the page to retry.
                  </p>
                </motion.div>
              )}

              {/* Result */}
              {result && !isLoading && (
                <motion.div key="result"
                  initial={{ opacity:0,y:12 }} animate={{ opacity:1,y:0 }}
                  exit={{ opacity:0 }} transition={{ duration:0.26 }}
                  style={{ background:"#ffffff",border:"1px solid rgba(0,0,0,0.07)",
                    borderRadius:22,padding:22,display:"flex",flexDirection:"column",gap:14,...S }}>

                  {/* Class + confidence header */}
                  <div style={{ display:"flex",alignItems:"center",gap:13 }}>
                    <div style={{ width:54,height:54,borderRadius:15,flexShrink:0,
                      background:"linear-gradient(135deg,rgba(124,58,237,0.09),rgba(91,33,182,0.04))",
                      display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.65rem",
                      boxShadow:"0 0 16px rgba(124,58,237,0.14)" }}>
                      {CLASS_EMOJIS[result.classIdx]}
                    </div>
                    <div style={{ flex:1,minWidth:0 }}>
                      <div style={{ display:"flex",alignItems:"center",gap:5,marginBottom:2 }}>
                        <CheckCircle2 size={12} color="#10b981"/>
                        <span style={{ fontSize:12,color:"#10b981",fontWeight:600 }}>
                          Classified · {result.inferenceMs}ms
                        </span>
                      </div>
                      <p style={{ fontSize:23,fontWeight:800,color:"#09090e",
                        letterSpacing:"-0.025em",lineHeight:1 }}>
                        {result.className}
                      </p>
                      <p style={{ fontSize:12,color:"#94a3b8",marginTop:2 }}>
                        CIFAR-10 class {result.classIdx} · MobileNetV2
                      </p>
                    </div>
                    <div style={{ textAlign:"right",flexShrink:0 }}>
                      <p style={{ fontSize:28,fontWeight:800,color:"#7c3aed",
                        lineHeight:1,letterSpacing:"-0.02em" }}>
                        <CountUp to={result.confidence} suffix="%"/>
                      </p>
                      <p style={{ fontSize:11,color:"#94a3b8",marginTop:2 }}>confidence</p>
                    </div>
                  </div>

                  {/* Confidence bar */}
                  <div style={{ height:4,background:"#f1f5f9",borderRadius:99,overflow:"hidden" }}>
                    <Bar pct={result.confidence}/>
                  </div>

                  {/* Radar chart */}
                  <div style={{ height:152 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={radar}>
                        <PolarGrid stroke="rgba(124,58,237,0.07)"/>
                        <PolarAngleAxis dataKey="s" tick={{ fontSize:9,fill:"#94a3b8" }}/>
                        <Radar name="Score" dataKey="v" stroke="#7c3aed" fill="#7c3aed"
                          fillOpacity={0.11} strokeWidth={1.8}/>
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Toggle all scores */}
                  <button onClick={()=>setAll(!showAll)}
                    style={{ display:"flex",alignItems:"center",gap:4,
                      background:"none",border:"none",cursor:"pointer",
                      fontSize:12,color:"#7c3aed",fontWeight:600,padding:0,...S }}>
                    {showAll?<ChevronUp size={12}/>:<ChevronDown size={12}/>}
                    {showAll?"Hide":"Show"} all class scores
                  </button>

                  <AnimatePresence>
                    {showAll && (
                      <motion.div initial={{ height:0,opacity:0 }}
                        animate={{ height:"auto",opacity:1 }}
                        exit={{ height:0,opacity:0 }}
                        transition={{ duration:0.2 }}
                        style={{ overflow:"hidden" }}>
                        <div style={{ display:"flex",flexDirection:"column",gap:5,paddingTop:2 }}>
                          {CLASS_NAMES.map((name,i) => (
                            <div key={i} style={{ display:"flex",alignItems:"center",gap:7 }}>
                              <span style={{ fontSize:12,width:16 }}>{CLASS_EMOJIS[i]}</span>
                              <span style={{ fontSize:11,color:"#64748b",width:76,flexShrink:0 }}>{name}</span>
                              <div style={{ flex:1,height:3,background:"#f1f5f9",borderRadius:99,overflow:"hidden" }}>
                                <Bar pct={result.allScores[i]} active={i===result.classIdx} delay={i*28}/>
                              </div>
                              <span style={{ fontSize:11,color:"#94a3b8",width:36,textAlign:"right" }}>
                                {result.allScores[i].toFixed(1)}%
                              </span>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <button
                    onClick={()=>{ setResult(null); setPrev(null); setAll(false); setImgEl(null); }}
                    style={{ display:"flex",alignItems:"center",gap:5,background:"none",border:"none",
                      cursor:"pointer",fontSize:11,color:"#94a3b8",padding:0,...S,transition:"color 0.1s" }}
                    onMouseEnter={e=>(e.currentTarget as HTMLElement).style.color="#7c3aed"}
                    onMouseLeave={e=>(e.currentTarget as HTMLElement).style.color="#94a3b8"}>
                    <RefreshCcw size={11}/> Try another image
                  </button>
                </motion.div>
              )}

              {/* Empty */}
              {!isLoading && !result && status !== "error" && (
                <motion.div key="empty" initial={{ opacity:0 }} animate={{ opacity:1 }}
                  style={{ background:"#ffffff",border:"1px solid rgba(0,0,0,0.07)",
                    borderRadius:22,padding:44,minHeight:300,
                    display:"flex",flexDirection:"column",alignItems:"center",
                    justifyContent:"center",gap:12,textAlign:"center",...S }}>
                  <div style={{ width:50,height:50,borderRadius:13,
                    background:"rgba(124,58,237,0.06)",border:"1px solid rgba(124,58,237,0.10)",
                    display:"flex",alignItems:"center",justifyContent:"center" }}>
                    <ImageIcon size={22} color="rgba(124,58,237,0.38)"/>
                  </div>
                  <p style={{ fontSize:14,color:"#94a3b8",maxWidth:210,lineHeight:1.55 }}>
                    {status==="ready"
                      ? "Upload an image or pick a sample to run real MobileNetV2 inference."
                      : "Loading model weights from MobileNetV2…"}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
