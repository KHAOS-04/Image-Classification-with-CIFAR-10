"use client";
import { useEffect, useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight } from "lucide-react";
import Image from "next/image";

function Staircase() {
  const steps = [
    { w:"13%",  h:240, top:"8%",  op:0.68 },
    { w:"23%",  h:208, top:"12%", op:0.54 },
    { w:"35%",  h:176, top:"16%", op:0.44 },
    { w:"50%",  h:144, top:"20%", op:0.33 },
    { w:"67%",  h:114, top:"24%", op:0.22 },
    { w:"85%",  h:86,  top:"28%", op:0.12 },
    { w:"103%", h:60,  top:"32%", op:0.06 },
  ];
  return (
    <div style={{ position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",pointerEvents:"none",overflow:"hidden" }}>
      {steps.map((s,i) => (
        <motion.div key={i}
          initial={{ opacity:0,y:18 }} animate={{ opacity:s.op,y:0 }}
          transition={{ duration:0.9,delay:0.05+i*0.07,ease:[0.22,1,0.36,1] }}
          style={{
            position:"absolute",width:s.w,height:s.h,top:s.top,
            background:`linear-gradient(160deg,rgba(196,181,253,${0.64-i*0.07}) 0%,rgba(167,139,250,${0.38-i*0.04}) 55%,rgba(124,58,237,${0.13-i*0.015}) 100%)`,
            borderRadius:26,
            animation:`aurora-a ${22+i*5}s cubic-bezier(0.45,0.05,0.55,0.95) infinite`,
            animationDelay:`${-i*3.5}s`,
            willChange:"transform",
          }}
        />
      ))}
    </div>
  );
}

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target:sectionRef, offset:["start start","end start"] });

  const contentY  = useTransform(scrollYProgress, [0,1], ["0px","120px"]);
  const contentOp = useTransform(scrollYProgress, [0,0.55], [1, 0]);
  const imageY    = useTransform(scrollYProgress, [0,1], ["0px","-50px"]);
  const imageS    = useTransform(scrollYProgress, [0,0.85], [1, 0.88]);
  const stairY    = useTransform(scrollYProgress, [0,1], ["0px","70px"]);

  return (
    <section ref={sectionRef} style={{ position:"relative",minHeight:"100svh",overflow:"hidden" }}>
      <motion.div style={{ position:"absolute",inset:0,zIndex:0,y:stairY,willChange:"transform" }}>
        <Staircase />
      </motion.div>

      <motion.div style={{ y:contentY,opacity:contentOp,willChange:"transform,opacity" }}
        initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ duration:0.3 }}>
        <div style={{
          position:"relative",zIndex:10,
          display:"flex",flexDirection:"column",alignItems:"center",textAlign:"center",
          padding:"clamp(60px,9vh,88px) 20px 44px",
        }}>

          {/* Eyebrow */}
          <motion.div
            initial={{ opacity:0,y:10 }} animate={{ opacity:1,y:0 }}
            transition={{ duration:0.45,delay:0.2,ease:[0.22,1,0.36,1] }}
            style={{
              display:"inline-flex",alignItems:"center",gap:7,
              background:"rgba(237,233,254,0.92)",
              border:"1px solid rgba(124,58,237,0.2)",
              borderRadius:20,padding:"6px 16px",
              marginBottom:"clamp(30px,5vh,46px)",
              fontSize:12,fontWeight:700,color:"#6d28d9",
              letterSpacing:"0.07em",textTransform:"uppercase",
              WebkitBackdropFilter:"blur(8px)",backdropFilter:"blur(8px)",
            }}
          >
            <span className="anim-pulse-dot" style={{ width:7,height:7,borderRadius:"50%",background:"#7c3aed",flexShrink:0 }}/>
            ICT 120 — Intelligent Systems
          </motion.div>

          {/* Hero image */}
          <motion.div
            initial={{ opacity:0,scale:0.82 }} animate={{ opacity:1,scale:1 }}
            transition={{ duration:0.9,delay:0.12,ease:[0.22,1,0.36,1] }}
            style={{ y:imageY,scale:imageS,position:"relative",marginBottom:"clamp(30px,5vh,46px)",willChange:"transform" }}
          >
            <div style={{
              position:"absolute",top:"50%",left:"50%",
              transform:"translate(-50%,-50%)",
              width:"150%",height:"140%",borderRadius:"50%",
              background:"radial-gradient(ellipse,rgba(124,58,237,0.30) 0%,rgba(192,38,211,0.14) 36%,transparent 68%)",
              filter:"blur(28px)",pointerEvents:"none",
            }}/>
            <motion.div animate={{ rotate:360 }} transition={{ duration:24,repeat:Infinity,ease:"linear" }}
              style={{ position:"absolute",inset:-20,borderRadius:"50%",border:"1.5px solid transparent",
                borderTopColor:"rgba(124,58,237,0.48)",borderRightColor:"rgba(196,181,253,0.18)",willChange:"transform" }}/>
            <motion.div animate={{ rotate:-360 }} transition={{ duration:36,repeat:Infinity,ease:"linear" }}
              style={{ position:"absolute",inset:-33,borderRadius:"50%",border:"1px dashed rgba(192,38,211,0.16)",willChange:"transform" }}/>
            <div className="anim-float" style={{ position:"relative",willChange:"transform" }}>
              <Image src="/visyra.png" alt="Visyra" width={272} height={181}
                style={{ objectFit:"contain",
                  filter:"drop-shadow(0 28px 52px rgba(91,33,182,0.58)) drop-shadow(0 8px 18px rgba(192,38,211,0.26))" }}
                priority/>
            </div>
          </motion.div>

          {/* Two-column flanking text */}
          <div style={{
            display:"grid",gridTemplateColumns:"1fr 1px 1fr",gap:"0 36px",
            alignItems:"start",width:"100%",maxWidth:820,marginBottom:38,textAlign:"left",
          }} className="max-sm:flex max-sm:flex-col max-sm:text-center max-sm:items-center">
            <motion.div initial={{ opacity:0,x:-16 }} animate={{ opacity:1,x:0 }}
              transition={{ duration:0.6,delay:0.38,ease:[0.22,1,0.36,1] }}>
              {/* ↑ HERO TITLE — enlarged */}
              <h1 style={{
                fontSize:"clamp(2.1rem,4vw,3rem)",
                fontWeight:800,lineHeight:1.07,
                letterSpacing:"-0.035em",color:"#09090e",
                fontFamily:"-apple-system,'SF Pro Display','Inter',system-ui,sans-serif",
              }}>
                Image Classification<br />with CIFAR-10
              </h1>
              <p style={{ marginTop:14,fontSize:15,lineHeight:1.7,color:"#64748b",maxWidth:270 }}>
                A project for{" "}
                <strong style={{ color:"#09090e",fontWeight:600 }}>ICT 120 — Intelligent Systems</strong>
                , a Convolutional Neural Network trained on 60,000 images across 10 object classes.
              </p>
            </motion.div>

            <div className="hide-mobile" style={{ background:"rgba(0,0,0,0.07)",alignSelf:"stretch",minHeight:90 }}/>

            <motion.div initial={{ opacity:0,x:16 }} animate={{ opacity:1,x:0 }}
              transition={{ duration:0.6,delay:0.44,ease:[0.22,1,0.36,1] }}
              style={{ display:"flex",flexDirection:"column",gap:16 }}
              className="max-sm:items-center max-sm:mt-6">
              {[
                { label:"Architecture", val:"MobileNetV2 + Custom Head" },
                { label:"Dataset",      val:"CIFAR-10 · 60,000 images" },
                { label:"Parameters",   val:"2.42M total · 165K trainable" },
                { label:"Inference",    val:"In-browser · TensorFlow.js" },
              ].map(({ label,val }) => (
                <div key={label}>
                  <div style={{ fontSize:11,fontWeight:700,color:"#94a3b8",textTransform:"uppercase",letterSpacing:"0.1em" }}>{label}</div>
                  <div style={{ fontSize:14.5,fontWeight:600,color:"#09090e",marginTop:2 }}>{val}</div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* CTA */}
          <motion.div initial={{ opacity:0,y:8 }} animate={{ opacity:1,y:0 }}
            transition={{ duration:0.45,delay:0.56,ease:[0.22,1,0.36,1] }}
            style={{ display:"flex",gap:14,alignItems:"center",flexWrap:"wrap",justifyContent:"center" }}>
            <a href="#predict" style={{
              display:"inline-flex",alignItems:"center",gap:8,
              background:"#09090e",color:"white",
              fontSize:14,fontWeight:700,letterSpacing:"-0.01em",
              padding:"13px 26px",borderRadius:24,textDecoration:"none",
              boxShadow:"0 4px 20px rgba(0,0,0,0.20)",
              transition:"transform 0.12s cubic-bezier(0.22,1,0.36,1),box-shadow 0.12s ease",
            }}
            onMouseEnter={e=>{ const el=e.currentTarget as HTMLElement; el.style.transform="translateY(-2px)"; el.style.boxShadow="0 8px 28px rgba(0,0,0,0.26)"; }}
            onMouseLeave={e=>{ const el=e.currentTarget as HTMLElement; el.style.transform="translateY(0)"; el.style.boxShadow="0 4px 20px rgba(0,0,0,0.20)"; }}>
              Try a Prediction <ArrowRight size={14}/>
            </a>
            <a href="#metrics" style={{
              display:"inline-flex",alignItems:"center",color:"#64748b",fontSize:14,fontWeight:500,
              textDecoration:"none",transition:"color 0.1s ease",
            }}
            onMouseEnter={e=>(e.currentTarget as HTMLElement).style.color="#09090e"}
            onMouseLeave={e=>(e.currentTarget as HTMLElement).style.color="#64748b"}>
              View results →
            </a>
          </motion.div>

          {/* Scroll cue */}
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ delay:1.0 }}
            style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:5,marginTop:"clamp(28px,4vh,42px)" }}>
            <span style={{ fontSize:10,color:"#94a3b8",letterSpacing:"0.2em",textTransform:"uppercase" }}>Scroll</span>
            <div style={{ width:1,height:26,background:"linear-gradient(to bottom,rgba(124,58,237,0.5),transparent)" }}/>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}
