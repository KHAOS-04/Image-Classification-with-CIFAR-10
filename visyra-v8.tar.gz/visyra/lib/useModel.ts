/**
 * useModel — loads the TF.js MobileNetV2 CIFAR-10 model once
 * and exposes a `predict(imageElement)` function.
 *
 * Architecture: MobileNetV2 (frozen) → GlobalAvgPool → Dense(128,ReLU) → Dropout(0.5) → Dense(10,Softmax)
 * Input: 32×32×3 float32 tensor (internal Resizing layer upscales to 96×96)
 * Output: softmax probabilities for 10 CIFAR-10 classes
 */
"use client";
import { useState, useEffect, useCallback, useRef } from "react";

// Lazy import — tfjs is 3MB, only loaded when hook is first used
async function loadTF() {
  const tf = await import("@tensorflow/tfjs");
  return tf;
}

export type PredictResult = {
  classIdx:   number;
  className:  string;
  confidence: number;
  allScores:  number[];
  inferenceMs: number;
};

const CLASS_NAMES = [
  "Airplane","Automobile","Bird","Cat","Deer",
  "Dog","Frog","Horse","Ship","Truck",
];
const CLASS_EMOJIS = ["✈️","🚗","🐦","🐱","🦌","🐶","🐸","🐴","🚢","🚛"];

export type ModelStatus = "idle" | "loading" | "ready" | "error";

export function useModel() {
  const modelRef  = useRef<Awaited<ReturnType<typeof import("@tensorflow/tfjs")>>["LayersModel"] | null>(null) as
    React.MutableRefObject<import("@tensorflow/tfjs").LayersModel | null>;
  const [status, setStatus]   = useState<ModelStatus>("idle");
  const [loadPct, setLoadPct] = useState(0);

  // Load model on first call
  const load = useCallback(async () => {
    if (modelRef.current || status === "loading") return;
    setStatus("loading");
    setLoadPct(10);
    try {
      const tf = await loadTF();
      setLoadPct(30);
      const model = await tf.loadLayersModel("/model/model.json", {
        onProgress: (fraction) => setLoadPct(30 + Math.round(fraction * 65)),
      });
      setLoadPct(100);
      modelRef.current = model;
      setStatus("ready");
    } catch (e) {
      console.error("Model load failed:", e);
      setStatus("error");
    }
  }, [status]);

  // Run prediction on an HTMLImageElement or HTMLCanvasElement
  const predict = useCallback(
    async (imgEl: HTMLImageElement | HTMLCanvasElement): Promise<PredictResult | null> => {
      const model = modelRef.current;
      if (!model) return null;

      const tf = await loadTF();
      const t0 = performance.now();

      const result = tf.tidy(() => {
        // Decode to [32,32,3] float32 normalized tensor
        let tensor = tf.browser.fromPixels(imgEl)           // [H, W, 3] uint8
          .resizeBilinear([32, 32])                         // [32, 32, 3]
          .toFloat()
          .div(255.0)                                       // [0,1]
          .expandDims(0) as import("@tensorflow/tfjs").Tensor4D; // [1,32,32,3]

        const output = model.predict(tensor) as import("@tensorflow/tfjs").Tensor2D;
        return Array.from(output.dataSync()) as number[];
      });

      const inferenceMs = Math.round(performance.now() - t0);
      const classIdx   = result.indexOf(Math.max(...result));
      const allScores  = result.map(v => parseFloat((v * 100).toFixed(1)));

      return {
        classIdx,
        className:  CLASS_NAMES[classIdx],
        confidence: allScores[classIdx],
        allScores,
        inferenceMs,
      };
    },
    []
  );

  return { status, loadPct, load, predict, CLASS_NAMES, CLASS_EMOJIS };
}
