/**
 * SectionHeader — shared typography component for all content sections.
 *
 * Ensures every section has identical:
 * • label size, weight, colour, tracking
 * • h2 size, weight, letter-spacing
 * • subtitle size, colour, line-height
 *
 * This eliminates the "flat typography in later sections" bug caused by
 * each section defining its own inline fontSize values independently.
 */
"use client";
import { motion } from "framer-motion";

interface Props {
  tag:   string;   // eyebrow label
  title: string;   // h2 headline
  sub:   string;   // subtitle paragraph
  id?:   string;   // scroll anchor id for the section
}

export default function SectionHeader({ tag, title, sub }: Props) {
  return (
    <motion.div
      initial={{ opacity:0, y:14 }}
      whileInView={{ opacity:1, y:0 }}
      viewport={{ once:true }}
      transition={{ duration:0.5, ease:[0.22,1,0.36,1] }}
      style={{ marginBottom:28 }}
    >
      {/* Eyebrow label */}
      <p style={{
        fontFamily: "-apple-system,'SF Pro Text','Inter',system-ui,sans-serif",
        fontSize: 12,
        fontWeight: 700,
        color: "#7c3aed",
        textTransform: "uppercase",
        letterSpacing: "0.15em",
        marginBottom: 9,
      }}>
        {tag}
      </p>

      {/* Section title */}
      <h2 style={{
        fontFamily: "-apple-system,'SF Pro Display','Inter',system-ui,sans-serif",
        fontSize: "clamp(1.9rem, 3.5vw, 2.65rem)",
        fontWeight: 800,
        letterSpacing: "-0.03em",
        color: "#09090e",
        lineHeight: 1.08,
      }}>
        {title}
      </h2>

      {/* Subtitle */}
      <p style={{
        fontFamily: "-apple-system,'SF Pro Text','Inter',system-ui,sans-serif",
        marginTop: 9,
        fontSize: 15,
        color: "#64748b",
        lineHeight: 1.68,
        maxWidth: 440,
      }}>
        {sub}
      </p>
    </motion.div>
  );
}
